[CmdletBinding()]
param(
    [string]$Version = "0.3.105"
)

$ErrorActionPreference = "Stop"
[Console]::OutputEncoding = [Text.UTF8Encoding]::new($false)
$script:InstallStage = "Starting installation"
$script:InstallOperation = "Preparing installer"
$script:InstallTarget = ""
$script:InstallAttempt = 0
$SourceRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$SourceBinary = Join-Path $SourceRoot "code-codex.exe"
$SourceRuntimeLauncher = Join-Path $SourceRoot "code-codex-launcher.exe"
$SourceShim = Join-Path $SourceRoot "code-codex-shim.exe"
$SourceShortcutTool = Join-Path $SourceRoot "code-codex-shortcut.exe"
$SourceUninstallerExecutable = Join-Path $SourceRoot "code-codex-uninstall.exe"
$SourceUninstaller = Join-Path $SourceRoot "Uninstall-CodeCodex.ps1"
$SourceFinalizer = Join-Path $SourceRoot "Finalize-Uninstall.ps1"
$SourceBrandIcon = Join-Path $SourceRoot "CodeCodex.Brand.png"
$InstallRoot = Join-Path $env:LOCALAPPDATA "Programs\Code-Codex"
$ProgramsRoot = [IO.Path]::GetFullPath((Join-Path $env:LOCALAPPDATA "Programs"))
$VersionsRoot = Join-Path $InstallRoot "versions"
$VersionRoot = Join-Path $VersionsRoot $Version

function Publish-CodeCodexProgress([int]$Percent, [string]$Stage, [string]$Detail) {
    $script:InstallStage = $Stage
    $script:InstallOperation = $Stage
    $script:InstallTarget = ""
    $script:InstallAttempt = 0
    if ([string]::IsNullOrWhiteSpace($env:CLE_PROGRESS_STATE_PATH)) { return }
    try {
        $message = [Convert]::ToBase64String(
            [Text.Encoding]::UTF8.GetBytes($Stage + "`n" + $Detail)
        )
        $command = "{0}|progress|{1}|{2}" -f [DateTime]::UtcNow.Ticks, $Percent, $message
        [IO.File]::WriteAllText($env:CLE_PROGRESS_STATE_PATH, $command, [Text.UTF8Encoding]::new($false))
    }
    catch {} # A display failure must not interrupt installation.
}

function Invoke-InstallFileOperation([string]$Operation, [string]$Target, [scriptblock]$Action) {
    $script:InstallOperation = $Operation
    $script:InstallTarget = $Target
    for ($attempt = 1; $attempt -le 3; $attempt++) {
        $script:InstallAttempt = $attempt
        try {
            & $Action
            return
        }
        catch {
            $code = [Convert]::ToString($_.Exception.GetBaseException().HResult, 16).ToUpperInvariant()
            if ($attempt -eq 3 -or $code -notin @("80070020", "80070021")) { throw }
            Start-Sleep -Milliseconds (150 * $attempt)
        }
    }
}

function Write-InstallDiagnostic($Failure) {
    $baseError = $Failure.Exception.GetBaseException()
    $hresult = [Convert]::ToString($baseError.HResult, 16).ToUpperInvariant().PadLeft(8, '0')
    $win32 = if ($hresult.StartsWith('8007')) { [Convert]::ToInt32($hresult.Substring(4), 16) } else { $null }
    $detail = [ordered]@{
        stage = $script:InstallStage
        operation = $script:InstallOperation
        targetName = if ($script:InstallTarget) { Split-Path -Leaf $script:InstallTarget } else { "" }
        targetExists = if ($script:InstallTarget) { Test-Path -LiteralPath $script:InstallTarget } else { $null }
        attempt = $script:InstallAttempt
        exception = $baseError.GetType().Name
        hresult = "0x$hresult"
        win32 = $win32
        line = $Failure.InvocationInfo.ScriptLineNumber
        messageBase64 = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($baseError.Message))
    }
    [Console]::Out.WriteLine('CODECODEX_INSTALL_ERROR:' + (ConvertTo-Json -InputObject $detail -Compress))
}

function Test-ReparsePoint([IO.FileSystemInfo]$Item) {
    return ($Item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0
}

function Get-ExistingItem([string]$Path) {
    return Get-Item -LiteralPath $Path -Force -ErrorAction SilentlyContinue
}

function Assert-RegularFile([string]$Path, [string]$Description) {
    $item = Get-ExistingItem $Path
    if ($null -eq $item -or
        $item.PSIsContainer -or
        $item -isnot [IO.FileInfo] -or
        (Test-ReparsePoint $item)) {
        throw "$Description must be a regular file: $Path"
    }
    return $item
}

function Get-Sha256Hash([string]$Path) {
    [void](Assert-RegularFile $Path "Hash input")
    $stream = [IO.File]::Open(
        $Path,
        [IO.FileMode]::Open,
        [IO.FileAccess]::Read,
        [IO.FileShare]::Read)
    $sha256 = [Security.Cryptography.SHA256]::Create()
    try {
        return ([BitConverter]::ToString($sha256.ComputeHash($stream))).Replace("-", "")
    }
    finally {
        $sha256.Dispose()
        $stream.Dispose()
    }
}

function Assert-SafeFileCopy([string]$Source, [string]$Destination) {
    [void](Assert-RegularFile $Source "Documentation source")

    $destinationDirectory = Split-Path -Parent $Destination
    $destinationDirectoryItem = Get-ExistingItem $destinationDirectory
    if ($null -ne $destinationDirectoryItem -and
        (-not $destinationDirectoryItem.PSIsContainer -or
            $destinationDirectoryItem -isnot [IO.DirectoryInfo] -or
            (Test-ReparsePoint $destinationDirectoryItem))) {
        throw "Documentation destination parent must be a regular directory: $destinationDirectory"
    }

    $destinationItem = Get-ExistingItem $Destination
    if ($null -ne $destinationItem -and
        ($destinationItem.PSIsContainer -or
            $destinationItem -isnot [IO.FileInfo] -or
            (Test-ReparsePoint $destinationItem))) {
        throw "Documentation destination must be a regular file: $Destination"
    }
}

function Assert-SafeDocumentTree([string]$Source, [string]$Destination) {
    $sourceItem = Get-ExistingItem $Source
    if ($null -eq $sourceItem -or
        -not $sourceItem.PSIsContainer -or
        $sourceItem -isnot [IO.DirectoryInfo] -or
        (Test-ReparsePoint $sourceItem)) {
        throw "Documentation source must be a regular directory: $Source"
    }

    $destinationItem = Get-ExistingItem $Destination
    if ($null -ne $destinationItem -and
        (-not $destinationItem.PSIsContainer -or
            $destinationItem -isnot [IO.DirectoryInfo] -or
            (Test-ReparsePoint $destinationItem))) {
        throw "Documentation destination must be a regular directory: $Destination"
    }

    foreach ($sourceChild in @(Get-ChildItem -LiteralPath $Source -Force -ErrorAction Stop)) {
        $destinationChild = Join-Path $Destination $sourceChild.Name
        if ($sourceChild.PSIsContainer) {
            Assert-SafeDocumentTree $sourceChild.FullName $destinationChild
        }
        else {
            Assert-SafeFileCopy $sourceChild.FullName $destinationChild
        }
    }
}

function Copy-AtomicFile([string]$Source, [string]$Destination) {
    [void](Assert-RegularFile $Source "Copy source")
    $destinationDirectory = Split-Path -Parent $Destination
    $destinationDirectoryItem = Get-ExistingItem $destinationDirectory
    if ($null -eq $destinationDirectoryItem) {
        New-Item -ItemType Directory -Path $destinationDirectory -Force | Out-Null
        $destinationDirectoryItem = Get-ExistingItem $destinationDirectory
    }
    if ($null -eq $destinationDirectoryItem -or
        -not $destinationDirectoryItem.PSIsContainer -or
        $destinationDirectoryItem -isnot [IO.DirectoryInfo] -or
        (Test-ReparsePoint $destinationDirectoryItem)) {
        throw "Copy destination parent must be a regular directory: $destinationDirectory"
    }

    $destinationItem = Get-ExistingItem $Destination
    if ($null -ne $destinationItem -and
        ($destinationItem.PSIsContainer -or
            $destinationItem -isnot [IO.FileInfo] -or
            (Test-ReparsePoint $destinationItem))) {
        throw "Copy destination must be a regular file: $Destination"
    }

    $temporary = Join-Path $destinationDirectory (".{0}.{1}.tmp" -f (Split-Path -Leaf $Destination), [Guid]::NewGuid().ToString("N"))
    $replacementBackup = Join-Path $destinationDirectory (".{0}.{1}.replace-backup" -f (Split-Path -Leaf $Destination), [Guid]::NewGuid().ToString("N"))
    try {
        Copy-Item -LiteralPath $Source -Destination $temporary
        $destinationItem = Get-ExistingItem $Destination
        if ($null -ne $destinationItem -and
            ($destinationItem.PSIsContainer -or
                $destinationItem -isnot [IO.FileInfo] -or
                (Test-ReparsePoint $destinationItem))) {
            throw "Copy destination must remain a regular file: $Destination"
        }
        if ($null -ne $destinationItem) {
            Invoke-InstallFileOperation "Replacing support file" $Destination {
                [IO.File]::Replace($temporary, $Destination, $replacementBackup, $true)
            }
            Remove-Item -LiteralPath $replacementBackup -Force -ErrorAction SilentlyContinue
        }
        else {
            Invoke-InstallFileOperation "Moving support file" $Destination {
                [IO.File]::Move($temporary, $Destination)
            }
        }
    }
    finally {
        Remove-Item -LiteralPath $temporary -Force -ErrorAction SilentlyContinue
        Remove-Item -LiteralPath $replacementBackup -Force -ErrorAction SilentlyContinue
    }
}

function Copy-SafeDocumentTree([string]$Source, [string]$Destination) {
    Assert-SafeDocumentTree $Source $Destination

    $destinationItem = Get-ExistingItem $Destination
    if ($null -eq $destinationItem) {
        $destinationParent = Split-Path -Parent $Destination
        $destinationParentItem = Get-ExistingItem $destinationParent
        if ($null -eq $destinationParentItem -or
            -not $destinationParentItem.PSIsContainer -or
            $destinationParentItem -isnot [IO.DirectoryInfo] -or
            (Test-ReparsePoint $destinationParentItem)) {
            throw "Documentation destination parent must be a regular directory: $destinationParent"
        }
        New-Item -ItemType Directory -Path $Destination | Out-Null
        $destinationItem = Get-ExistingItem $Destination
    }
    if ($null -eq $destinationItem -or
        -not $destinationItem.PSIsContainer -or
        $destinationItem -isnot [IO.DirectoryInfo] -or
        (Test-ReparsePoint $destinationItem)) {
        throw "Documentation destination must be a regular directory: $Destination"
    }

    foreach ($sourceChild in @(Get-ChildItem -LiteralPath $Source -Force -ErrorAction Stop)) {
        $destinationChild = Join-Path $Destination $sourceChild.Name
        if ($sourceChild.PSIsContainer) {
            Copy-SafeDocumentTree $sourceChild.FullName $destinationChild
        }
        else {
            Assert-SafeFileCopy $sourceChild.FullName $destinationChild
            Copy-AtomicFile $sourceChild.FullName $destinationChild
        }
    }
}

function Write-AtomicText([string]$Destination, [string]$Content) {
    $directory = Split-Path -Parent $Destination
    New-Item -ItemType Directory -Path $directory -Force | Out-Null
    $temporary = Join-Path $directory (".{0}.{1}.tmp" -f (Split-Path -Leaf $Destination), [Guid]::NewGuid().ToString("N"))
    $replacementBackup = Join-Path $directory (".{0}.{1}.replace-backup" -f (Split-Path -Leaf $Destination), [Guid]::NewGuid().ToString("N"))
    try {
        [IO.File]::WriteAllText($temporary, $Content, [Text.UTF8Encoding]::new($false))
        if (Test-Path -LiteralPath $Destination -PathType Leaf) {
            Invoke-InstallFileOperation "Replacing installation marker" $Destination {
                [IO.File]::Replace($temporary, $Destination, $replacementBackup, $true)
            }
            Remove-Item -LiteralPath $replacementBackup -Force -ErrorAction SilentlyContinue
        }
        else {
            Invoke-InstallFileOperation "Moving installation marker" $Destination {
                [IO.File]::Move($temporary, $Destination)
            }
        }
    }
    finally {
        Remove-Item -LiteralPath $temporary -Force -ErrorAction SilentlyContinue
        Remove-Item -LiteralPath $replacementBackup -Force -ErrorAction SilentlyContinue
    }
}

$script:InstallRollbackPrepared = $false
$script:CreatedVersionRoot = $false
$script:InstallCommitted = $false
$previousVersionMarker = $null
$previousInstallTypeMarker = $null
$script:VersionSnapshotTaken = $false
$script:RegistrySnapshotTaken = $false
$previousRegistryEntry = $null
$script:CleanupIssues = @()
try {
if ($Version -notmatch '^(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)$' -or $Version.Length -gt 32) {
    throw "Release version must be a bounded three-part numeric version: $Version"
}
Publish-CodeCodexProgress 62 "Checking installation" "Verifying package files and the destination folder."

$requiredPayload = @(
    $SourceBinary,
    $SourceRuntimeLauncher,
    $SourceShim,
    $SourceShortcutTool,
    $SourceUninstallerExecutable,
    $SourceUninstaller,
    $SourceFinalizer,
    $SourceBrandIcon
)
foreach ($payload in $requiredPayload) {
    $item = Get-ExistingItem $payload
    if ($null -eq $item -or $item.PSIsContainer -or (Test-ReparsePoint $item)) {
        throw "Required payload must be a regular file next to this installer: $payload"
    }
}

$programsItem = Get-ExistingItem $ProgramsRoot
if ($null -ne $programsItem -and
    (-not $programsItem.PSIsContainer -or (Test-ReparsePoint $programsItem))) {
    throw "Refusing to install through a non-directory or reparse-point Programs path: $ProgramsRoot"
}
$existingInstall = Get-ExistingItem $InstallRoot
if ($null -ne $existingInstall -and
    (-not $existingInstall.PSIsContainer -or (Test-ReparsePoint $existingInstall))) {
    throw "Refusing to install into a non-directory or reparse-point path: $InstallRoot"
}

$documentCopies = @()
foreach ($document in @(
    "README.md",
    "README.en.md",
    "LICENSE",
    "THIRD_PARTY_NOTICES_EN.md",
    "THIRD_PARTY_NOTICES_ZH_CN.md",
    "THIRD_PARTY_LICENSES.txt",
    "sbom.spdx.json"
)) {
    $sourceDocument = Join-Path $SourceRoot $document
    if ($null -ne (Get-ExistingItem $sourceDocument)) {
        $destinationDocument = Join-Path $InstallRoot $document
        Assert-SafeFileCopy $sourceDocument $destinationDocument
        $documentCopies += [PSCustomObject]@{
            Source = $sourceDocument
            Destination = $destinationDocument
        }
    }
}
$sourceDocs = Join-Path $SourceRoot "docs"
$installedDocs = Join-Path $InstallRoot "docs"
$installDocumentation = $null -ne (Get-ExistingItem $sourceDocs)
if ($installDocumentation) {
    Assert-SafeDocumentTree $sourceDocs $installedDocs
}

$installFullPath = [IO.Path]::GetFullPath($InstallRoot)
$programsPrefix = $ProgramsRoot.TrimEnd([IO.Path]::DirectorySeparatorChar, [IO.Path]::AltDirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar
$versionFullPath = [IO.Path]::GetFullPath($VersionRoot)
$installPrefix = $installFullPath.TrimEnd([IO.Path]::DirectorySeparatorChar, [IO.Path]::AltDirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar
if (-not $installFullPath.StartsWith($programsPrefix, [StringComparison]::OrdinalIgnoreCase) -or
    -not $versionFullPath.StartsWith($installPrefix, [StringComparison]::OrdinalIgnoreCase)) {
    throw "Refusing to install outside the expected per-user Programs directory."
}

$installTypePath = Join-Path $InstallRoot "install-type"
$installTypeItem = Get-ExistingItem $installTypePath
if ($null -ne $installTypeItem) {
    if ($installTypeItem.PSIsContainer -or (Test-ReparsePoint $installTypeItem)) {
        throw "Refusing to read a non-file or reparse-point installation ownership marker: $installTypePath"
    }
    if ((Get-Content -LiteralPath $installTypePath -Raw -Encoding UTF8).Trim() -eq "msi") {
        throw "Code-Codex is owned by Windows Installer. Uninstall it through Windows Installed apps before using the standalone installer."
    }
}

$msiProductCodePattern = '^\{[0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{12}\}$'
$uninstallRegistryRoot = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall"
$uninstallRegistryPattern = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*"
$existingMsiRegistration = $null
if (Test-Path -LiteralPath $uninstallRegistryRoot) {
    $existingMsiRegistration = Get-ItemProperty $uninstallRegistryPattern -ErrorAction Stop |
        Where-Object {
            $_.DisplayName -eq "Code-Codex" -and
            [string]$_.PSChildName -match $msiProductCodePattern -and
            [string]$_.WindowsInstaller -eq "1"
        } |
        Select-Object -First 1
}
if ($null -ne $existingMsiRegistration) {
    throw "Code-Codex is registered with Windows Installer. Uninstall it through Windows Installed apps before using the standalone installer."
}

Publish-CodeCodexProgress 68 "Checking Codex integration" "Validating the official Codex installation and shortcuts."
& $SourceShortcutTool preflight --install-root $InstallRoot --version $Version
if ($LASTEXITCODE -ne 0) {
    throw "Stable Codex could not be validated for Code-Codex integration. No installation files were changed."
}
$script:InstallOperation = "Creating installation directory"
New-Item -ItemType Directory -Path $InstallRoot -Force | Out-Null
$installRootItem = Get-ExistingItem $InstallRoot
if ($null -eq $installRootItem -or -not $installRootItem.PSIsContainer -or (Test-ReparsePoint $installRootItem)) {
    throw "The installation root must be a regular directory."
}
$script:InstallOperation = "Saving shortcut rollback state"
& $SourceShortcutTool prepare-install --install-root $InstallRoot | Out-Null
if ($LASTEXITCODE -ne 0) { throw "The shortcut rollback state could not be prepared." }
$script:InstallRollbackPrepared = $true
$previousVersionPath = Join-Path $InstallRoot "current-version"
$previousInstallTypePath = Join-Path $InstallRoot "install-type"
if (Test-Path -LiteralPath $previousVersionPath -PathType Leaf) {
    $previousVersionMarker = [IO.File]::ReadAllText($previousVersionPath)
}
if (Test-Path -LiteralPath $previousInstallTypePath -PathType Leaf) {
    $previousInstallTypeMarker = [IO.File]::ReadAllText($previousInstallTypePath)
}
$script:VersionSnapshotTaken = $true

New-Item -ItemType Directory -Path $VersionsRoot -Force | Out-Null
$versionsItem = Get-Item -LiteralPath $VersionsRoot -Force
if (-not $versionsItem.PSIsContainer -or (Test-ReparsePoint $versionsItem)) {
    throw "The versions path must be a regular directory: $VersionsRoot"
}

if (Test-Path -LiteralPath $VersionRoot) {
    Publish-CodeCodexProgress 74 "Verifying application files" "Comparing the installed binaries with this package."
    $versionItem = Get-Item -LiteralPath $VersionRoot -Force
    if (-not $versionItem.PSIsContainer -or (Test-ReparsePoint $versionItem)) {
        throw "The release path must be a regular directory: $VersionRoot"
    }
    foreach ($pair in @(
        @($SourceBinary, (Join-Path $VersionRoot "code-codex.exe")),
        @($SourceRuntimeLauncher, (Join-Path $VersionRoot "CodeCodex.exe"))
    )) {
        if (-not (Test-Path -LiteralPath $pair[1] -PathType Leaf) -or
            (Get-Sha256Hash $pair[0]) -ne (Get-Sha256Hash $pair[1])) {
            throw "Version $Version is already installed with a different payload. Use a new release version."
        }
    }
}
else {
    Publish-CodeCodexProgress 74 "Installing application files" "Copying the Code-Codex binaries into the version folder."
    $stagingVersion = Join-Path $VersionsRoot (".{0}.{1}.tmp" -f $Version, [Guid]::NewGuid().ToString("N"))
    try {
        New-Item -ItemType Directory -Path $stagingVersion | Out-Null
        Copy-Item -LiteralPath $SourceBinary -Destination (Join-Path $stagingVersion "code-codex.exe")
        Copy-Item -LiteralPath $SourceRuntimeLauncher -Destination (Join-Path $stagingVersion "CodeCodex.exe")
        Invoke-InstallFileOperation "Moving version directory" $VersionRoot {
            [IO.Directory]::Move($stagingVersion, $VersionRoot)
        }
        $script:CreatedVersionRoot = $true
    }
    finally {
        if (Test-Path -LiteralPath $stagingVersion) {
            try { Remove-Item -LiteralPath $stagingVersion -Recurse -Force -ErrorAction Stop }
            catch { $script:CleanupIssues += "staging directory cleanup failed" }
        }
    }
}

Publish-CodeCodexProgress 81 "Installing support files" "Updating the launcher, uninstaller, and documentation."
Copy-AtomicFile $SourceShim (Join-Path $InstallRoot "CodeCodex.exe")
Copy-AtomicFile $SourceShortcutTool (Join-Path $InstallRoot "CodeCodex.Shortcut.exe")
Copy-AtomicFile $SourceUninstallerExecutable (Join-Path $InstallRoot "Uninstall-CodeCodex.exe")
Copy-AtomicFile $SourceUninstaller (Join-Path $InstallRoot "Uninstall-CodeCodex.ps1")
Copy-AtomicFile $SourceFinalizer (Join-Path $InstallRoot "Finalize-Uninstall.ps1")
Copy-AtomicFile $SourceBrandIcon (Join-Path $InstallRoot "CodeCodex.Brand.png")

foreach ($documentCopy in $documentCopies) {
    Assert-SafeFileCopy $documentCopy.Source $documentCopy.Destination
    Copy-AtomicFile $documentCopy.Source $documentCopy.Destination
}
if ($installDocumentation) {
    Copy-SafeDocumentTree $sourceDocs $installedDocs
}

Write-AtomicText (Join-Path $InstallRoot "current-version") ($Version + "`n")
Write-AtomicText (Join-Path $InstallRoot "install-type") "portable`n"

Publish-CodeCodexProgress 88 "Registering installation" "Updating the Windows installed-app entry."
# Remove the obsolete sign-in launch entry. The existing Codex or ChatGPT
# shortcut is now the single user-controlled entry point for both the official
# app and Code-Codex.
Remove-ItemProperty `
    -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Run" `
    -Name "CodeCodex" `
    -ErrorAction SilentlyContinue

$uninstallKey = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\CodeCodex"
$previousRegistryEntry = Get-ItemProperty -LiteralPath $uninstallKey -ErrorAction SilentlyContinue
$script:RegistrySnapshotTaken = $true
New-Item -Path $uninstallKey -Force | Out-Null
New-ItemProperty -Path $uninstallKey -Name "DisplayName" -PropertyType String -Value "Code-Codex" -Force | Out-Null
New-ItemProperty -Path $uninstallKey -Name "DisplayVersion" -PropertyType String -Value $Version -Force | Out-Null
New-ItemProperty -Path $uninstallKey -Name "Publisher" -PropertyType String -Value "Code-Codex contributors" -Force | Out-Null
New-ItemProperty -Path $uninstallKey -Name "InstallLocation" -PropertyType String -Value $InstallRoot -Force | Out-Null
New-ItemProperty -Path $uninstallKey -Name "DisplayIcon" -PropertyType String -Value (Join-Path $InstallRoot "Uninstall-CodeCodex.exe") -Force | Out-Null
New-ItemProperty -Path $uninstallKey -Name "UninstallString" -PropertyType String `
    -Value ('"{0}"' -f (Join-Path $InstallRoot "Uninstall-CodeCodex.exe")) -Force | Out-Null
New-ItemProperty -Path $uninstallKey -Name "NoModify" -PropertyType DWord -Value 1 -Force | Out-Null
New-ItemProperty -Path $uninstallKey -Name "NoRepair" -PropertyType DWord -Value 1 -Force | Out-Null

$installedShortcutTool = Join-Path $InstallRoot "CodeCodex.Shortcut.exe"
Publish-CodeCodexProgress 94 "Updating shortcuts" "Linking the Codex desktop shortcut to Code-Codex."
$shortcutResultJson = & $installedShortcutTool install --install-root $InstallRoot --version $Version --preserve-legacy
$shortcutExitCode = $LASTEXITCODE
if ($shortcutExitCode -ne 0) {
    throw "The Codex or ChatGPT desktop shortcut could not be redirected, or the Code-Codex shortcut could not be created (exit code $shortcutExitCode)."
}
$shortcutResult = ($shortcutResultJson -join "`n") | ConvertFrom-Json
$managedShortcut = [string]$shortcutResult.shortcutPath
if (-not $managedShortcut -or -not (Test-Path -LiteralPath $managedShortcut -PathType Leaf)) {
    throw "Code-Codex could not verify the installed desktop shortcut."
}
$script:InstallOperation = "Verifying installed payload and shortcut"
foreach ($pair in @(
    @($SourceBinary, (Join-Path $VersionRoot "code-codex.exe")),
    @($SourceRuntimeLauncher, (Join-Path $VersionRoot "CodeCodex.exe")),
    @($SourceShim, (Join-Path $InstallRoot "CodeCodex.exe")),
    @($SourceShortcutTool, $installedShortcutTool),
    @($SourceUninstallerExecutable, (Join-Path $InstallRoot "Uninstall-CodeCodex.exe"))
)) {
    if (-not (Test-Path -LiteralPath $pair[1] -PathType Leaf) -or
        (Get-Sha256Hash $pair[0]) -ne (Get-Sha256Hash $pair[1])) {
        throw "Installed file verification failed for $([IO.Path]::GetFileName($pair[1]))."
    }
}
if (([IO.File]::ReadAllText($previousVersionPath)).Trim() -ne $Version) {
    throw "The active installed version was not updated."
}
$shortcutStatusJson = & $installedShortcutTool status --install-root $InstallRoot
if ($LASTEXITCODE -ne 0) { throw "The installed shortcut status could not be verified." }
$shortcutStatus = ($shortcutStatusJson -join "`n") | ConvertFrom-Json
if ([string]$shortcutStatus.state -ne "managed" -or
    [string]$shortcutStatus.installedVersion -ne $Version -or
    [string]$shortcutStatus.shortcutPath -ne $managedShortcut) {
    throw "The installed shortcut does not point to the verified version."
}
$script:InstallOperation = "Committing shortcut installation"
& $installedShortcutTool commit-install --install-root $InstallRoot | Out-Null
if ($LASTEXITCODE -ne 0) { throw "The shortcut installation could not be committed." }
$script:InstallRollbackPrepared = $false
$script:InstallCommitted = $true
Publish-CodeCodexProgress 96 "Shortcut ready" "Code-Codex will start from $([IO.Path]::GetFileNameWithoutExtension($managedShortcut))."

$installedCommandLine = Join-Path $VersionRoot "code-codex.exe"
Publish-CodeCodexProgress 98 "Activating Code-Codex" "Refreshing any currently open Codex window."
try {
    Start-Process `
        -FilePath $installedCommandLine `
        -ArgumentList @("activate") `
        -WindowStyle Hidden | Out-Null
}
catch {
    Write-Warning "Code-Codex was installed, but the currently open Codex window could not be updated automatically: $($_.Exception.Message)"
}

Write-Host "Code-Codex managed shortcut: $managedShortcut"
Write-Host "Installed Code-Codex $Version. Open the managed desktop shortcut to start Codex with Code-Codex."
}
catch {
    $failure = $_
    $rollbackIssues = @($script:CleanupIssues)
    if (-not $script:InstallCommitted) {
        if ($script:InstallRollbackPrepared) {
            & $SourceShortcutTool rollback-install --install-root $InstallRoot | Out-Null
            if ($LASTEXITCODE -ne 0) { $rollbackIssues += "shortcut rollback failed" }
        }
        if ($script:VersionSnapshotTaken) {
        foreach ($marker in @(@($previousVersionPath, $previousVersionMarker), @($previousInstallTypePath, $previousInstallTypeMarker))) {
            if (-not $marker[0]) { continue }
            try {
                if ($null -eq $marker[1]) {
                    Remove-Item -LiteralPath $marker[0] -Force -ErrorAction SilentlyContinue
                }
                else {
                    [IO.File]::WriteAllText($marker[0], [string]$marker[1], [Text.UTF8Encoding]::new($false))
                }
            }
            catch { $rollbackIssues += "version marker rollback failed" }
        }
        }
        if ($script:RegistrySnapshotTaken) {
            try {
                if ($null -eq $previousRegistryEntry) {
                    Remove-Item -LiteralPath $uninstallKey -Force -ErrorAction SilentlyContinue
                }
                else {
                    foreach ($name in @('DisplayName', 'DisplayVersion', 'Publisher', 'InstallLocation', 'DisplayIcon', 'UninstallString', 'NoModify', 'NoRepair')) {
                        $property = $previousRegistryEntry.PSObject.Properties[$name]
                        if ($null -eq $property) {
                            Remove-ItemProperty -LiteralPath $uninstallKey -Name $name -ErrorAction SilentlyContinue
                        }
                        else {
                            Set-ItemProperty -LiteralPath $uninstallKey -Name $name -Value $property.Value -ErrorAction Stop
                        }
                    }
                }
            }
            catch { $rollbackIssues += "installed-app registration rollback failed" }
        }
        if ($script:CreatedVersionRoot -and $VersionRoot.StartsWith($VersionsRoot + '\', [StringComparison]::OrdinalIgnoreCase)) {
            try { Remove-Item -LiteralPath $VersionRoot -Recurse -Force -ErrorAction Stop }
            catch { $rollbackIssues += "new version directory cleanup failed" }
        }
    }
    Write-InstallDiagnostic $failure
    if ($rollbackIssues.Count -gt 0) {
        [Console]::Out.WriteLine('CODECODEX_ROLLBACK_ERROR:' + ($rollbackIssues -join '; '))
    }
    exit 1
}
