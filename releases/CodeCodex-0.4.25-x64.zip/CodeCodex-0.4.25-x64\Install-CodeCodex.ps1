[CmdletBinding()]
param(
    [string]$Version = "0.4.25",
    [string]$InstallRoot,
    [switch]$SelectDirectory,
    [switch]$NoActivate
)

# storage-contract:start
# Shared install/uninstall location contract. No recursive operation follows a reparse point.
function Get-CodeCodexRegisteredRoot {
    $entry = Get-ItemProperty 'HKCU:\Software\CodeCodex' -ErrorAction SilentlyContinue
    if ($entry -and $entry.InstallPath) { return [string]$entry.InstallPath }
    $old = Get-ItemProperty 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\CodeCodex' -ErrorAction SilentlyContinue
    if ($old -and $old.InstallLocation) { return [string]$old.InstallLocation }
    if ($entry -and $entry.RetainedRoot) { return [string]$entry.RetainedRoot }
    return Join-Path $env:LOCALAPPDATA 'Programs\Code-Codex'
}

function Assert-CodeCodexRoot([string]$Root, [switch]$Owned) {
    if ($Root -notmatch '^[A-Za-z]:[\\/]' -or $Root.Contains('"') -or $Root.Contains('..') -or $Root.Length -gt 180) {
        throw 'Choose a bounded absolute folder on a local drive (no network, relative or device paths).'
    }
    $full = [IO.Path]::GetFullPath($Root).TrimEnd('\', '/')
    if ($full.Length -le 3 -or $full.EndsWith('.') -or $full.EndsWith(' ')) { throw 'A drive root is not an application folder.' }
    foreach ($protected in @($env:USERPROFILE, $env:LOCALAPPDATA, $env:APPDATA, $env:WINDIR, $env:ProgramFiles, ${env:ProgramFiles(x86)}, [Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('MyDocuments'))) {
        if ($protected -and $full.Equals([IO.Path]::GetFullPath($protected).TrimEnd('\'), [StringComparison]::OrdinalIgnoreCase)) { throw 'Choose a dedicated Code-Codex folder, not a system or personal folder itself.' }
        if ($protected -and $protected -in @($env:WINDIR, $env:ProgramFiles, ${env:ProgramFiles(x86)}) -and $full.StartsWith($protected.TrimEnd('\')+'\', [StringComparison]::OrdinalIgnoreCase)) { throw 'Choose a user-writable folder outside Windows and Program Files.' }
    }
    $drive = [IO.DriveInfo]::new([IO.Path]::GetPathRoot($full))
    if (-not $drive.IsReady -or $drive.DriveType -ne [IO.DriveType]::Fixed) { throw 'Installation requires an available fixed local drive.' }
    $cursor = $full
    while ($cursor) {
        $item = Get-Item -LiteralPath $cursor -Force -ErrorAction SilentlyContinue
        if ($item -and (-not $item.PSIsContainer -or ($item.Attributes -band [IO.FileAttributes]::ReparsePoint))) { throw "Linked or non-directory storage ancestor refused: $cursor" }
        $cursor = Split-Path -Parent $cursor
    }
    if ($Owned) {
        $marker = Join-Path $full 'storage-layout.json'
        $item = Get-Item -LiteralPath $marker -Force -ErrorAction SilentlyContinue
        if ($item) {
            if ($item.PSIsContainer -or ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -or $item.Length -gt 4096) { throw 'Invalid or redirected storage marker; ownership refused.' }
            $layout = [IO.File]::ReadAllText($marker) | ConvertFrom-Json
            if ($layout.schema -eq 1 -and $layout.product -eq 'Code-Codex') { return $full }
            throw 'Unsupported storage marker; legacy ownership fallback refused.'
        }
        $legacy = [IO.Path]::GetFullPath((Join-Path $env:LOCALAPPDATA 'Programs\Code-Codex'))
        $legacyMarker = Get-Item -LiteralPath (Join-Path $full 'install-type') -Force -ErrorAction SilentlyContinue
        if (-not $full.Equals($legacy,[StringComparison]::OrdinalIgnoreCase) -or -not $legacyMarker -or $legacyMarker.PSIsContainer -or ($legacyMarker.Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw 'Application ownership could not be verified; no files will be removed.' }
    }
    return $full
}

function Copy-CodeCodexDataTree([string]$Source, [string]$Destination) {
    $item = Get-Item -LiteralPath $Source -Force -ErrorAction SilentlyContinue
    if (-not $item) { return }
    if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw "Redirected migration source refused: $Source" }
    $existing = Get-Item -LiteralPath $Destination -Force -ErrorAction SilentlyContinue
    if ($existing -and ($existing.Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw "Redirected migration destination refused: $Destination" }
    if ($item.PSIsContainer) {
        if ($existing -and -not $existing.PSIsContainer) { throw 'Migration destination has conflicting file type.' }
        New-Item -ItemType Directory -Path $Destination -Force | Out-Null
        foreach ($child in Get-ChildItem -LiteralPath $Source -Force) {
            Copy-CodeCodexDataTree $child.FullName (Join-Path $Destination $child.Name)
        }
    } else {
        if ($existing) {
            # Newer destination data wins. Keep the original source for recovery.
            $script:MigrationSkipped++
            return
        }
        New-Item -ItemType Directory -Path (Split-Path -Parent $Destination) -Force | Out-Null
        $stage = $Destination + '.' + [Guid]::NewGuid().ToString('N') + '.tmp'
        try {
            Copy-Item -LiteralPath $Source -Destination $stage
            if ((Get-FileHash -LiteralPath $Source -Algorithm SHA256).Hash -ne (Get-FileHash -LiteralPath $stage -Algorithm SHA256).Hash) { throw 'Migrated resource hash mismatch.' }
            [IO.File]::Move($stage, $Destination)
            $script:MigrationCopied++
        } finally { if (Test-Path -LiteralPath $stage) { Remove-Item -LiteralPath $stage -Force } }
    }
}

function Measure-CodeCodexMigration([string]$Source, [string]$Destination) {
    $item = Get-Item -LiteralPath $Source -Force -ErrorAction SilentlyContinue
    if (-not $item) { return [long]0 }
    if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw "Redirected migration source refused: $Source" }
    if (-not $item.PSIsContainer) { if (Test-Path -LiteralPath $Destination) { return [long]0 }; return [long]$item.Length }
    [long]$size = 0
    foreach ($child in Get-ChildItem -LiteralPath $Source -Force) { $size += Measure-CodeCodexMigration $child.FullName (Join-Path $Destination $child.Name) }
    return $size
}

function Test-CodeCodexAtomicStorage([string]$Root, [scriptblock]$Progress = {param($phase,$status)}) {
    $full = Assert-CodeCodexRoot $Root
    if (-not (Test-Path -LiteralPath $full -PathType Container)) { throw 'Atomic storage probe requires an existing verified directory.' }
    $prefix = Join-Path $full ('.atomic-check-' + [Guid]::NewGuid().ToString('N'))
    $source = $prefix + '.source'; $target = $prefix + '.target'; $replacement = $prefix + '.replacement'; $backup = $prefix + '.backup'
    $phase = 'create'; $failure = $null; $cleanup = @()
    try {
        & $Progress $phase 'started'
        [IO.File]::WriteAllText($source,'probe-source')
        & $Progress $phase 'passed'
        $phase = 'rename'; & $Progress $phase 'started'
        [IO.File]::Move($source,$target)
        & $Progress $phase 'passed'
        $phase = 'replace'; & $Progress $phase 'started'
        [IO.File]::WriteAllText($replacement,'probe-replacement')
        [IO.File]::Replace($replacement,$target,$backup,$true)
        if ([IO.File]::ReadAllText($target) -ne 'probe-replacement') { throw 'Atomic replacement probe content mismatch.' }
        & $Progress $phase 'passed'
    } catch { $failure = $_; & $Progress $phase 'failed' }
    finally {
        foreach ($path in @($source,$target,$replacement,$backup)) {
            try {
                # Only these four exact task-created regular nodes are eligible.
                if ([IO.Path]::GetDirectoryName($path) -ne $full) { throw 'Probe cleanup path escaped its verified root.' }
                $item = Get-Item -LiteralPath $path -Force -ErrorAction SilentlyContinue
                if ($item) {
                    if ($item.PSIsContainer -or ($item.Attributes -band [IO.FileAttributes]::ReparsePoint)) { throw 'Probe cleanup encountered a redirected node.' }
                    Remove-Item -LiteralPath $path -Force
                }
            } catch { $cleanup += $_.Exception.GetBaseException().Message }
        }
        & $Progress 'cleanup' $(if ($cleanup.Count) {'partial'} else {'passed'})
    }
    if ($failure) { throw [IO.IOException]::new(('Storage replacement preflight failed; phase='+$phase+'; cleanupIssues='+$cleanup.Count),$failure.Exception) }
    if ($cleanup.Count) { throw [IO.IOException]::new(('Storage probe cleanup failed: '+($cleanup -join '; '))) }
}

function Initialize-CodeCodexStorage([string]$Root) {
    $script:MigrationCopied = 0; $script:MigrationSkipped = 0
    [long]$required = 100MB
    $legacy = Join-Path $env:LOCALAPPDATA 'CodeCodex'
    foreach ($pair in @(@('settings.json','data\settings.json'),@('runtime-logs','logs\runtime'),@('diagnostics','logs\diagnostics'),@('plugin-cache\plugins','plugins'))) {
        $required += Measure-CodeCodexMigration (Join-Path $legacy $pair[0]) (Join-Path $Root $pair[1])
    }
    $previous = Get-ItemProperty 'HKCU:\Software\CodeCodex' -ErrorAction SilentlyContinue
    if ($previous -and $previous.RetainedRoot) {
        $previousRoot = Assert-CodeCodexRoot ([string]$previous.RetainedRoot) -Owned
        if (-not $Root.Equals($previousRoot,[StringComparison]::OrdinalIgnoreCase)) {
            foreach ($relative in @('data','plugins','logs','backups')) { $required += Measure-CodeCodexMigration (Join-Path $previousRoot $relative) (Join-Path $Root $relative) }
        }
    }
    $drive = [IO.DriveInfo]::new([IO.Path]::GetPathRoot($Root))
    if ($drive.AvailableFreeSpace -lt $required) { throw "Insufficient space for verified migration and installation: required=$required; available=$($drive.AvailableFreeSpace)." }
    foreach ($relative in @('data','plugins','logs\runtime','logs\diagnostics','logs\install','logs\update','temp','backups')) {
        $target = Join-Path $Root $relative
        $null = Assert-CodeCodexRoot $target
        New-Item -ItemType Directory -Path $target -Force | Out-Null
    }
    # Keep private preferences and diagnostic content private even on a shared data drive.
    foreach ($relative in @('data','logs','temp','backups')) {
        $target = Join-Path $Root $relative
        $acl = [IO.Directory]::GetAccessControl($target, [Security.AccessControl.AccessControlSections]::Access)
        $acl.SetAccessRuleProtection($true, $false)
        foreach ($existingRule in @($acl.Access)) { $null = $acl.RemoveAccessRuleSpecific($existingRule) }
        foreach ($sid in @([Security.Principal.WindowsIdentity]::GetCurrent().User, [Security.Principal.SecurityIdentifier]::new('S-1-5-18'), [Security.Principal.SecurityIdentifier]::new('S-1-5-32-544'))) {
            $rule = [Security.AccessControl.FileSystemAccessRule]::new($sid, 'FullControl', 'ContainerInherit,ObjectInherit', 'None', 'Allow')
            $acl.AddAccessRule($rule)
        }
        [IO.Directory]::SetAccessControl($target, $acl)
    }
    $registered = Get-ItemProperty 'HKCU:\Software\CodeCodex' -ErrorAction SilentlyContinue
    $retained = if ($registered) { [string]$registered.RetainedRoot } else { '' }
    if ($retained -and -not $Root.Equals($retained,[StringComparison]::OrdinalIgnoreCase)) {
        $retained = Assert-CodeCodexRoot $retained -Owned
        foreach ($relative in @('data','plugins','logs','backups')) {
            Copy-CodeCodexDataTree (Join-Path $retained $relative) (Join-Path $Root $relative)
        }
    }
    $old = Join-Path $env:LOCALAPPDATA 'CodeCodex'
    foreach ($pair in @(@('settings.json','data\settings.json'),@('runtime-logs','logs\runtime'),@('diagnostics','logs\diagnostics'))) {
        Copy-CodeCodexDataTree (Join-Path $old $pair[0]) (Join-Path $Root $pair[1])
    }
    $oldPlugins = Join-Path $old 'plugin-cache'
    if (Test-Path -LiteralPath $oldPlugins) {
        $null = Assert-CodeCodexRoot $oldPlugins
        foreach ($item in Get-ChildItem -LiteralPath $oldPlugins -Force) {
            if ($item.Name -eq 'plugins' -or $item.Name -match '^[a-z0-9-]+-[a-f0-9]{64}\.js$') {
                Copy-CodeCodexDataTree $item.FullName (Join-Path $Root $item.Name)
            }
        }
    }
    $report = [ordered]@{schema=1;copied=$script:MigrationCopied;preservedDestination=$script:MigrationSkipped;sourceRetained=$true;retainedRootMigrated=[bool]($retained -and -not $Root.Equals($retained,[StringComparison]::OrdinalIgnoreCase));completedAt=[DateTime]::UtcNow.ToString('o')}
    [IO.File]::WriteAllText((Join-Path $Root 'backups\legacy-migration.json'),($report|ConvertTo-Json),[Text.UTF8Encoding]::new($false))
}

function Show-CodeCodexDirectoryChoice([string]$Initial, [bool]$Existing) {
    Add-Type -AssemblyName System.Windows.Forms
    $form = New-Object Windows.Forms.Form
    $form.Text='Code-Codex installation'; $form.Width=620; $form.Height=225
    $form.StartPosition='CenterScreen'; $form.FormBorderStyle='FixedDialog'; $form.MaximizeBox=$false; $form.MinimizeBox=$false; $form.TopMost=$true
    $label=New-Object Windows.Forms.Label; $label.Text=if($Existing){'Update in the existing folder. Settings, plugins and logs are preserved.'}else{'Choose one folder for Code-Codex, settings, plugins and logs.'}; $label.SetBounds(20,18,560,32); $form.Controls.Add($label)
    $box=New-Object Windows.Forms.TextBox; $box.Text=$Initial; $box.SetBounds(20,57,460,26); $box.ReadOnly=$Existing; $form.Controls.Add($box)
    $browse=New-Object Windows.Forms.Button; $browse.Text='Browse...'; $browse.SetBounds(488,55,90,30); $browse.Enabled=-not $Existing; $form.Controls.Add($browse)
    $browse.Add_Click({$dialog=New-Object Windows.Forms.FolderBrowserDialog; $dialog.Description='Select a parent folder. A dedicated Code-Codex subfolder will be created.'; if($dialog.ShowDialog() -eq 'OK'){$box.Text=Join-Path $dialog.SelectedPath 'Code-Codex'}; $dialog.Dispose()}.GetNewClosure())
    $note=New-Object Windows.Forms.Label; $note.Text='Default: current user installation on C: (no administrator rights required).'; $note.SetBounds(20,92,560,25); $form.Controls.Add($note)
    $ok=New-Object Windows.Forms.Button; $ok.Text=if($Existing){'Update'}else{'Install'}; $ok.SetBounds(388,130,90,32); $ok.DialogResult='OK'; $form.Controls.Add($ok); $form.AcceptButton=$ok
    $cancel=New-Object Windows.Forms.Button; $cancel.Text='Cancel'; $cancel.SetBounds(488,130,90,32); $cancel.DialogResult='Cancel'; $form.Controls.Add($cancel); $form.CancelButton=$cancel
    try { if($form.ShowDialog() -ne 'OK'){return $null}; return $box.Text } finally { $form.Dispose() }
}
# storage-contract:end

$ErrorActionPreference = "Stop"
[Console]::OutputEncoding = [Text.UTF8Encoding]::new($false)
$script:InstallStage = "Starting installation"
$script:InstallOperation = "Preparing installer"
$script:InstallTarget = ""
$script:InstallAttempt = 0
$SourceRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$SourceBinary = Join-Path $SourceRoot "code-codex.exe"
$SourceRuntimeLauncher = Join-Path $SourceRoot "code-codex-launcher.exe"
$SourceShim = Join-Path $SourceRoot "code-codex-shim.exe"
$SourceShortcutTool = Join-Path $SourceRoot "code-codex-shortcut.exe"
$SourceUninstallerExecutable = Join-Path $SourceRoot "code-codex-uninstall.exe"
$SourceUninstaller = Join-Path $SourceRoot "Uninstall-CodeCodex.ps1"
$SourceFinalizer = Join-Path $SourceRoot "Finalize-Uninstall.ps1"
$SourceBrandIcon = Join-Path $SourceRoot "CodeCodex.Brand.png"
$RegisteredRoot = Get-CodeCodexRegisteredRoot
if ([string]::IsNullOrWhiteSpace($InstallRoot)) { $InstallRoot = $RegisteredRoot }
$VersionsRoot = $null
$VersionRoot = $null
$StorageRegistryBefore = Get-ItemProperty 'HKCU:\Software\CodeCodex' -ErrorAction SilentlyContinue
$StorageMarkerBefore = $null
$script:StorageSnapshotTaken = $false

$script:InstallTrace = [Collections.Generic.List[object]]::new()
$script:InstallClock = [Diagnostics.Stopwatch]::StartNew()
function Trace-Install([string]$Phase, [string]$Outcome, [int]$Attempt = 0) {
    if ($script:InstallTrace.Count -ge 128) { $script:InstallTrace.RemoveAt(0) }
    $script:InstallTrace.Add([ordered]@{ elapsedMs=$script:InstallClock.ElapsedMilliseconds; phase=$Phase; outcome=$Outcome; attempt=$Attempt })
}
Trace-Install 'entry' 'started'

function Publish-CodeCodexProgress([int]$Percent, [string]$Stage, [string]$Detail) {
    Trace-Install $Stage 'started'
    $script:InstallStage = $Stage
    $script:InstallOperation = $Stage
    $script:InstallTarget = ""
    $script:InstallAttempt = 0
    if ([string]::IsNullOrWhiteSpace($env:CLE_PROGRESS_STATE_PATH)) { return }
    try {
        $message = [Convert]::ToBase64String(
            [Text.Encoding]::UTF8.GetBytes($Stage + "`n" + $Detail)
        )
        $command = "{0}|progress|{1}|{2}" -f [DateTime]::UtcNow.Ticks, $Percent, $message
        [IO.File]::WriteAllText($env:CLE_PROGRESS_STATE_PATH, $command, [Text.UTF8Encoding]::new($false))
    }
    catch {} # A display failure must not interrupt installation.
}

function Invoke-InstallFileOperation([string]$Operation, [string]$Target, [scriptblock]$Action) {
    $script:InstallOperation = $Operation
    $script:InstallTarget = $Target
    for ($attempt = 1; $attempt -le 3; $attempt++) {
        $script:InstallAttempt = $attempt
        try {
            Trace-Install $Operation 'started' $attempt
            & $Action
            Trace-Install $Operation 'passed' $attempt
            return
        }
        catch {
            Trace-Install $Operation 'failed' $attempt
            $code = [Convert]::ToString($_.Exception.GetBaseException().HResult, 16).ToUpperInvariant()
            if ($attempt -eq 3 -or $code -notin @("80070020", "80070021")) { throw }
            Trace-Install $Operation 'retry scheduled' ($attempt + 1)
            Start-Sleep -Milliseconds (150 * $attempt)
        }
    }
}

function Write-InstallDiagnostic($Failure) {
    $baseError = $Failure.Exception.GetBaseException()
    $hresult = [Convert]::ToString($baseError.HResult, 16).ToUpperInvariant().PadLeft(8, '0')
    $win32 = if ($hresult.StartsWith('8007')) { [Convert]::ToInt32($hresult.Substring(4), 16) } else { $null }
    $causes = @(); $cause=$Failure.Exception
    while ($null -ne $cause -and $causes.Count -lt 8) {
        $causes += [ordered]@{exceptionType=$cause.GetType().FullName;hresult=$cause.HResult;messageBase64=[Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($cause.Message))}
        $cause=$cause.InnerException
    }
    $detail = [ordered]@{
        schema = 2
        timeline = @($script:InstallTrace.ToArray())
        exceptionChain = $causes
        chainTruncated = ($null -ne $cause)
        errorId = $Failure.FullyQualifiedErrorId
        category = [string]$Failure.CategoryInfo.Category
        processEnvironment = [ordered]@{ powershell=$PSVersionTable.PSVersion.ToString(); languageMode=[string]$ExecutionContext.SessionState.LanguageMode; process64Bit=[Environment]::Is64BitProcess; os64Bit=[Environment]::Is64BitOperatingSystem }
        stage = $script:InstallStage
        operation = $script:InstallOperation
        targetName = if ($script:InstallTarget) { Split-Path -Leaf $script:InstallTarget } else { "" }
        targetExists = if ($script:InstallTarget) { Test-Path -LiteralPath $script:InstallTarget } else { $null }
        attempt = $script:InstallAttempt
        exception = $baseError.GetType().Name
        hresult = "0x$hresult"
        win32 = $win32
        line = $Failure.InvocationInfo.ScriptLineNumber
        messageBase64 = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($baseError.Message))
    }
    [Console]::Out.WriteLine('CODECODEX_INSTALL_ERROR:' + (ConvertTo-Json -InputObject $detail -Depth 8 -Compress))
}

function Test-ReparsePoint([IO.FileSystemInfo]$Item) {
    return ($Item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0
}

function Get-ExistingItem([string]$Path) {
    return Get-Item -LiteralPath $Path -Force -ErrorAction SilentlyContinue
}

function Assert-RegularFile([string]$Path, [string]$Description) {
    $item = Get-ExistingItem $Path
    if ($null -eq $item -or
        $item.PSIsContainer -or
        $item -isnot [IO.FileInfo] -or
        (Test-ReparsePoint $item)) {
        throw "$Description must be a regular file: $Path"
    }
    return $item
}

function Get-Sha256Hash([string]$Path) {
    [void](Assert-RegularFile $Path "Hash input")
    $stream = [IO.File]::Open(
        $Path,
        [IO.FileMode]::Open,
        [IO.FileAccess]::Read,
        [IO.FileShare]::Read)
    $sha256 = [Security.Cryptography.SHA256]::Create()
    try {
        return ([BitConverter]::ToString($sha256.ComputeHash($stream))).Replace("-", "")
    }
    finally {
        $sha256.Dispose()
        $stream.Dispose()
    }
}

function Assert-SafeFileCopy([string]$Source, [string]$Destination) {
    [void](Assert-RegularFile $Source "Documentation source")

    $destinationDirectory = Split-Path -Parent $Destination
    $destinationDirectoryItem = Get-ExistingItem $destinationDirectory
    if ($null -ne $destinationDirectoryItem -and
        (-not $destinationDirectoryItem.PSIsContainer -or
            $destinationDirectoryItem -isnot [IO.DirectoryInfo] -or
            (Test-ReparsePoint $destinationDirectoryItem))) {
        throw "Documentation destination parent must be a regular directory: $destinationDirectory"
    }

    $destinationItem = Get-ExistingItem $Destination
    if ($null -ne $destinationItem -and
        ($destinationItem.PSIsContainer -or
            $destinationItem -isnot [IO.FileInfo] -or
            (Test-ReparsePoint $destinationItem))) {
        throw "Documentation destination must be a regular file: $Destination"
    }
}

function Assert-SafeDocumentTree([string]$Source, [string]$Destination) {
    $sourceItem = Get-ExistingItem $Source
    if ($null -eq $sourceItem -or
        -not $sourceItem.PSIsContainer -or
        $sourceItem -isnot [IO.DirectoryInfo] -or
        (Test-ReparsePoint $sourceItem)) {
        throw "Documentation source must be a regular directory: $Source"
    }

    $destinationItem = Get-ExistingItem $Destination
    if ($null -ne $destinationItem -and
        (-not $destinationItem.PSIsContainer -or
            $destinationItem -isnot [IO.DirectoryInfo] -or
            (Test-ReparsePoint $destinationItem))) {
        throw "Documentation destination must be a regular directory: $Destination"
    }

    foreach ($sourceChild in @(Get-ChildItem -LiteralPath $Source -Force -ErrorAction Stop)) {
        $destinationChild = Join-Path $Destination $sourceChild.Name
        if ($sourceChild.PSIsContainer) {
            Assert-SafeDocumentTree $sourceChild.FullName $destinationChild
        }
        else {
            Assert-SafeFileCopy $sourceChild.FullName $destinationChild
        }
    }
}

function Copy-AtomicFile([string]$Source, [string]$Destination) {
    [void](Assert-RegularFile $Source "Copy source")
    $destinationDirectory = Split-Path -Parent $Destination
    $destinationDirectoryItem = Get-ExistingItem $destinationDirectory
    if ($null -eq $destinationDirectoryItem) {
        New-Item -ItemType Directory -Path $destinationDirectory -Force | Out-Null
        $destinationDirectoryItem = Get-ExistingItem $destinationDirectory
    }
    if ($null -eq $destinationDirectoryItem -or
        -not $destinationDirectoryItem.PSIsContainer -or
        $destinationDirectoryItem -isnot [IO.DirectoryInfo] -or
        (Test-ReparsePoint $destinationDirectoryItem)) {
        throw "Copy destination parent must be a regular directory: $destinationDirectory"
    }

    $destinationItem = Get-ExistingItem $Destination
    if ($null -ne $destinationItem -and
        ($destinationItem.PSIsContainer -or
            $destinationItem -isnot [IO.FileInfo] -or
            (Test-ReparsePoint $destinationItem))) {
        throw "Copy destination must be a regular file: $Destination"
    }

    $temporary = Join-Path $destinationDirectory (".{0}.{1}.tmp" -f (Split-Path -Leaf $Destination), [Guid]::NewGuid().ToString("N"))
    $replacementBackup = Join-Path $destinationDirectory (".{0}.{1}.replace-backup" -f (Split-Path -Leaf $Destination), [Guid]::NewGuid().ToString("N"))
    try {
        Copy-Item -LiteralPath $Source -Destination $temporary
        $destinationItem = Get-ExistingItem $Destination
        if ($null -ne $destinationItem -and
            ($destinationItem.PSIsContainer -or
                $destinationItem -isnot [IO.FileInfo] -or
                (Test-ReparsePoint $destinationItem))) {
            throw "Copy destination must remain a regular file: $Destination"
        }
        if ($null -ne $destinationItem) {
            Invoke-InstallFileOperation "Replacing support file" $Destination {
                [IO.File]::Replace($temporary, $Destination, $replacementBackup, $true)
            }
            Remove-Item -LiteralPath $replacementBackup -Force -ErrorAction SilentlyContinue
        }
        else {
            Invoke-InstallFileOperation "Moving support file" $Destination {
                [IO.File]::Move($temporary, $Destination)
            }
        }
    }
    finally {
        Remove-Item -LiteralPath $temporary -Force -ErrorAction SilentlyContinue
        Remove-Item -LiteralPath $replacementBackup -Force -ErrorAction SilentlyContinue
    }
}

function Copy-SafeDocumentTree([string]$Source, [string]$Destination) {
    Assert-SafeDocumentTree $Source $Destination

    $destinationItem = Get-ExistingItem $Destination
    if ($null -eq $destinationItem) {
        $destinationParent = Split-Path -Parent $Destination
        $destinationParentItem = Get-ExistingItem $destinationParent
        if ($null -eq $destinationParentItem -or
            -not $destinationParentItem.PSIsContainer -or
            $destinationParentItem -isnot [IO.DirectoryInfo] -or
            (Test-ReparsePoint $destinationParentItem)) {
            throw "Documentation destination parent must be a regular directory: $destinationParent"
        }
        New-Item -ItemType Directory -Path $Destination | Out-Null
        $destinationItem = Get-ExistingItem $Destination
    }
    if ($null -eq $destinationItem -or
        -not $destinationItem.PSIsContainer -or
        $destinationItem -isnot [IO.DirectoryInfo] -or
        (Test-ReparsePoint $destinationItem)) {
        throw "Documentation destination must be a regular directory: $Destination"
    }

    foreach ($sourceChild in @(Get-ChildItem -LiteralPath $Source -Force -ErrorAction Stop)) {
        $destinationChild = Join-Path $Destination $sourceChild.Name
        if ($sourceChild.PSIsContainer) {
            Copy-SafeDocumentTree $sourceChild.FullName $destinationChild
        }
        else {
            Assert-SafeFileCopy $sourceChild.FullName $destinationChild
            Copy-AtomicFile $sourceChild.FullName $destinationChild
        }
    }
}

function Write-AtomicText([string]$Destination, [string]$Content) {
    # Version-independent storage markers need no replacement during a hot update.
    # Preserve the existing file when content is identical, including rollback.
    if (Test-Path -LiteralPath $Destination -PathType Leaf) {
        [void](Assert-RegularFile $Destination "Installation marker")
        if ([IO.File]::ReadAllText($Destination) -eq $Content) { return }
    }
    $directory = Split-Path -Parent $Destination
    New-Item -ItemType Directory -Path $directory -Force | Out-Null
    $temporary = Join-Path $directory (".{0}.{1}.tmp" -f (Split-Path -Leaf $Destination), [Guid]::NewGuid().ToString("N"))
    $replacementBackup = Join-Path $directory (".{0}.{1}.replace-backup" -f (Split-Path -Leaf $Destination), [Guid]::NewGuid().ToString("N"))
    try {
        [IO.File]::WriteAllText($temporary, $Content, [Text.UTF8Encoding]::new($false))
        if (Test-Path -LiteralPath $Destination -PathType Leaf) {
            Invoke-InstallFileOperation "Replacing installation marker" $Destination {
                [IO.File]::Replace($temporary, $Destination, $replacementBackup, $true)
            }
            Remove-Item -LiteralPath $replacementBackup -Force -ErrorAction SilentlyContinue
        }
        else {
            Invoke-InstallFileOperation "Moving installation marker" $Destination {
                [IO.File]::Move($temporary, $Destination)
            }
        }
    }
    finally {
        Remove-Item -LiteralPath $temporary -Force -ErrorAction SilentlyContinue
        Remove-Item -LiteralPath $replacementBackup -Force -ErrorAction SilentlyContinue
    }
}

$script:InstallRollbackPrepared = $false
function Save-CodeCodexInstallReport([string]$Outcome) {
    try {
        $owned = $false
        if ($script:StorageSnapshotTaken -and (Test-Path -LiteralPath (Join-Path $InstallRoot 'storage-layout.json') -PathType Leaf)) {
            try { $null=Assert-CodeCodexRoot $InstallRoot -Owned; $owned=$true } catch { $owned=$false }
        }
        $folder = if ($owned) { Join-Path $InstallRoot 'logs\install' } else { Join-Path $env:TEMP 'CodeCodex\logs\install' }
        $null = Assert-CodeCodexRoot $folder
        New-Item -ItemType Directory -Path $folder -Force | Out-Null
        $report=[ordered]@{schema=1;version=$Version;outcome=$Outcome;timeline=@($script:InstallTrace.ToArray());migrationCopied=$script:MigrationCopied;migrationSkipped=$script:MigrationSkipped;rollbackIssues=@($script:CleanupIssues);versionRetention=$script:VersionRetentionReport}
        $path=Join-Path $folder ('install-'+[DateTime]::UtcNow.ToString('yyyyMMddHHmmssfff')+'-'+$PID+'.json')
        [IO.File]::WriteAllText($path,($report|ConvertTo-Json -Depth 8),[Text.UTF8Encoding]::new($false))
        Get-ChildItem -LiteralPath $folder -Filter 'install-*.json' -File | Sort-Object Name -Descending | Select-Object -Skip 10 | ForEach-Object { if(-not ($_.Attributes -band [IO.FileAttributes]::ReparsePoint)){Remove-Item -LiteralPath $_.FullName -Force} }
    } catch { Write-Warning ('Install report could not be saved: '+$_.Exception.Message) }
}

# Cleanup is a post-commit maintenance action, never part of rollback. Unknown
# files and busy versions are retained; no recursive delete follows a directory.
function Remove-CodeCodexOldVersions([string]$Root, [string]$Current, [string]$Previous, [bool]$Committed,
    [scriptblock]$Processes = { Get-CimInstance Win32_Process -OperationTimeoutSec 3 -ErrorAction Stop | Select-Object Name,ExecutablePath,ProcessId }) {
    $clock = [Diagnostics.Stopwatch]::StartNew()
    $report = [ordered]@{policy='current-and-previous';current=$Current;previous=$null;outcome='skipped';reason=$null;reclaimedBytes=0L;entries=@();durationMs=0L}
    Trace-Install 'Version retention' 'started'
    try {
        if (-not $Committed) { $report.reason='installation not committed'; return $report }
        $pattern = '^(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)$'
        if ($Current -notmatch $pattern -or $Current.Length -gt 32) { throw 'Invalid current version.' }
        $full = Assert-CodeCodexRoot $Root -Owned
        $marker = Get-Item -LiteralPath (Join-Path $full 'current-version') -Force -ErrorAction Stop
        if ($marker.PSIsContainer -or (Test-ReparsePoint $marker) -or $marker.Length -gt 64 -or
            ([IO.File]::ReadAllText($marker.FullName)).Trim() -ne $Current) { throw 'Active version marker does not match the committed installation.' }
        $versions = Join-Path $full 'versions'
        $null = Assert-CodeCodexRoot $versions
        $directories = @(Get-ChildItem -LiteralPath $versions -Force -ErrorAction Stop)
        $currentDirectory = Get-Item -LiteralPath (Join-Path $versions $Current) -Force -ErrorAction Stop
        if (-not $currentDirectory.PSIsContainer -or (Test-ReparsePoint $currentDirectory)) { throw 'Invalid current version directory.' }
        foreach ($binary in @('code-codex.exe','CodeCodex.exe')) {
            $currentFile = Get-Item -LiteralPath (Join-Path $currentDirectory.FullName $binary) -Force -ErrorAction Stop
            if ($currentFile.PSIsContainer -or (Test-ReparsePoint $currentFile)) { throw 'Invalid current version binary.' }
        }
        $eligible = @($directories | Where-Object { $_.PSIsContainer -and -not (Test-ReparsePoint $_) -and $_.Name.Length -le 32 -and $_.Name -match $pattern -and $null -ne ($_.Name -as [version]) })
        # Keep the actual version that was active before this update, including
        # an explicit downgrade. Repair installs fall back to the nearest older version.
        $previousName = if ($Previous) { $Previous.Trim() } else { '' }
        if ($previousName -ne $Current -and $previousName -match $pattern -and $eligible.Name -contains $previousName) {
            $report.previous = $previousName
        } else {
            $fallback = @($eligible | Where-Object { [version]$_.Name -lt [version]$Current } | Sort-Object { [version]$_.Name } -Descending | Select-Object -First 1)
            if ($fallback.Count) { $report.previous = $fallback[0].Name }
        }
        $candidates = @($directories | Where-Object { $_.Name -ne $Current -and $_.Name -ne $report.previous })
        if (-not $candidates.Count) { $report.outcome='passed'; return $report }
        # An unavailable executable path for a product process is not proof that
        # it is idle. Fail closed, rather than kill processes to reclaim space.
        $snapshot = @(& $Processes)
        if (@($snapshot | Where-Object { $_.Name -in @('code-codex.exe','CodeCodex.exe','code-codex-launcher.exe') -and -not $_.ExecutablePath }).Count) {
            throw 'A Code-Codex process executable path could not be inspected.'
        }
        foreach ($directory in $candidates) {
            $entry = [ordered]@{version=$directory.Name;outcome='retained';phase='directory verification';reason=$null;errorType=$null;hresult=$null;bytes=0L;removedBytes=0L;processIds=@()}
            $handles = [Collections.Generic.List[IDisposable]]::new()
            try {
                $candidate = [IO.Path]::GetFullPath($directory.FullName)
                if ([IO.Path]::GetDirectoryName($candidate) -ne $versions -or -not $directory.PSIsContainer -or
                    (Test-ReparsePoint $directory) -or $directory.Name -notmatch $pattern -or $null -eq ($directory.Name -as [version])) {
                    throw 'Unknown or redirected version entry.'
                }
                if ([version]$directory.Name -gt [version]$Current) { throw 'A newer version is not an older-version cleanup candidate.' }
                $null = Assert-CodeCodexRoot $candidate
                $children = @(Get-ChildItem -LiteralPath $candidate -Force -ErrorAction Stop)
                if ($children.Count -ne 2 -or @($children | Where-Object { $_.PSIsContainer -or (Test-ReparsePoint $_) -or $_.Name -notin @('code-codex.exe','CodeCodex.exe') }).Count) {
                    throw 'Version directory has additional, missing or redirected files.'
                }
                $entry.phase='process check'
                $active = @($snapshot | Where-Object { $_.ExecutablePath -and $_.ExecutablePath.StartsWith($candidate+'\',[StringComparison]::OrdinalIgnoreCase) })
                if ($active.Count) { $entry.processIds=@($active.ProcessId); throw 'Version is still used by a running process.' }
                # Hold both binaries against new readers/executions before removing
                # either one. FileShare.Delete permits this maintenance delete only.
                $entry.phase='lock binaries'
                foreach ($child in $children) {
                    $handles.Add([IO.File]::Open($child.FullName,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::Delete))
                    $entry.bytes += $child.Length
                }
                $entry.phase='delete binaries'
                foreach ($child in $children) {
                    [IO.File]::Delete($child.FullName)
                    $report.reclaimedBytes += $child.Length
                    $entry.removedBytes += $child.Length
                }
                foreach ($handle in $handles) { $handle.Dispose() }; $handles.Clear()
                $entry.phase='remove empty directory'
                [IO.Directory]::Delete($candidate, $false)
                $entry.outcome='removed'
            } catch {
                $entry.reason=$_.Exception.GetBaseException().Message
                $entry.errorType=$_.Exception.GetBaseException().GetType().FullName
                $entry.hresult=$_.Exception.GetBaseException().HResult
                if ($entry.removedBytes) { $entry.outcome='partial' }
            } finally {
                foreach ($handle in $handles) { $handle.Dispose() }
                $report.entries += $entry
                Trace-Install ('Version retention '+$directory.Name) $entry.outcome
            }
        }
        $report.outcome = if (@($report.entries | Where-Object outcome -ne 'removed').Count) { 'partial' } else { 'passed' }
    } catch {
        $report.reason=$_.Exception.GetBaseException().Message
    } finally {
        $report.durationMs=$clock.ElapsedMilliseconds
        Trace-Install 'Version retention' $report.outcome
    }
    return $report
}

$script:CreatedVersionRoot = $false
$script:InstallCommitted = $false
$script:VersionRetentionReport = [ordered]@{policy='current-and-previous';outcome='not-run';reason='installation has not committed'}
$previousVersionMarker = $null
$previousInstallTypeMarker = $null
$script:VersionSnapshotTaken = $false
$script:RegistrySnapshotTaken = $false
$previousRegistryEntry = $null
$script:CleanupIssues = @()
try {
if ($Version -notmatch '^(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)$' -or $Version.Length -gt 32) {
    throw "Release version must be a bounded three-part numeric version: $Version"
}
Publish-CodeCodexProgress 62 "Checking installation" "Verifying package files and the destination folder."

$requiredPayload = @(
    $SourceBinary,
    $SourceRuntimeLauncher,
    $SourceShim,
    $SourceShortcutTool,
    $SourceUninstallerExecutable,
    $SourceUninstaller,
    $SourceFinalizer,
    $SourceBrandIcon
)
foreach ($payload in $requiredPayload) {
    $item = Get-ExistingItem $payload
    if ($null -eq $item -or $item.PSIsContainer -or (Test-ReparsePoint $item)) {
        throw "Required payload must be a regular file next to this installer: $payload"
    }
}

$installedBefore = Test-Path -LiteralPath (Join-Path $RegisteredRoot 'current-version') -PathType Leaf
if ($SelectDirectory) {
    $selected = Show-CodeCodexDirectoryChoice $InstallRoot $installedBefore
    if ($null -eq $selected) { Write-Host 'CODECODEX_INSTALL_CANCELLED'; exit 0 }
    $InstallRoot = $selected
}
$InstallRoot = Assert-CodeCodexRoot $InstallRoot
if ($installedBefore -and -not $InstallRoot.Equals([IO.Path]::GetFullPath($RegisteredRoot).TrimEnd('\'),[StringComparison]::OrdinalIgnoreCase)) {
    throw 'An existing installation must be updated in its registered folder. To relocate, uninstall with KeepSettings first, then select the new folder.'
}
$VersionsRoot = Join-Path $InstallRoot 'versions'
$VersionRoot = Join-Path $VersionsRoot $Version
if (Test-Path -LiteralPath $InstallRoot) {
    $children = @(Get-ChildItem -LiteralPath $InstallRoot -Force)
    if ($children.Count -gt 0 -and -not (Test-Path -LiteralPath (Join-Path $InstallRoot 'storage-layout.json')) -and -not $installedBefore) {
        throw 'The selected folder is not empty or owned by Code-Codex. Choose an empty dedicated folder.'
    }
}
$disk = [IO.DriveInfo]::new([IO.Path]::GetPathRoot($InstallRoot))
if ($disk.AvailableFreeSpace -lt 100MB) { throw 'At least 100 MB of free disk space is required before installation and migration.' }
$existingInstall = Get-ExistingItem $InstallRoot
if ($null -ne $existingInstall -and
    (-not $existingInstall.PSIsContainer -or (Test-ReparsePoint $existingInstall))) {
    throw "Refusing to install into a non-directory or reparse-point path: $InstallRoot"
}

$documentCopies = @()
foreach ($document in @(
    "README.md",
    "README.en.md",
    "LICENSE",
    "THIRD_PARTY_NOTICES_EN.md",
    "THIRD_PARTY_NOTICES_ZH_CN.md",
    "THIRD_PARTY_LICENSES.txt",
    "sbom.spdx.json"
)) {
    $sourceDocument = Join-Path $SourceRoot $document
    if ($null -ne (Get-ExistingItem $sourceDocument)) {
        $destinationDocument = Join-Path $InstallRoot $document
        Assert-SafeFileCopy $sourceDocument $destinationDocument
        $documentCopies += [PSCustomObject]@{
            Source = $sourceDocument
            Destination = $destinationDocument
        }
    }
}
$sourceDocs = Join-Path $SourceRoot "docs"
$installedDocs = Join-Path $InstallRoot "docs"
$installDocumentation = $null -ne (Get-ExistingItem $sourceDocs)
if ($installDocumentation) {
    Assert-SafeDocumentTree $sourceDocs $installedDocs
}

$installFullPath = [IO.Path]::GetFullPath($InstallRoot)
$versionFullPath = [IO.Path]::GetFullPath($VersionRoot)
$installPrefix = $installFullPath.TrimEnd([IO.Path]::DirectorySeparatorChar, [IO.Path]::AltDirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar
if (-not $versionFullPath.StartsWith($installPrefix, [StringComparison]::OrdinalIgnoreCase)) {
    throw "Refusing a version path outside the selected installation root."
}

$installTypePath = Join-Path $InstallRoot "install-type"
$installTypeItem = Get-ExistingItem $installTypePath
if ($null -ne $installTypeItem) {
    if ($installTypeItem.PSIsContainer -or (Test-ReparsePoint $installTypeItem)) {
        throw "Refusing to read a non-file or reparse-point installation ownership marker: $installTypePath"
    }
    if ((Get-Content -LiteralPath $installTypePath -Raw -Encoding UTF8).Trim() -eq "msi") {
        throw "Code-Codex is owned by Windows Installer. Uninstall it through Windows Installed apps before using the standalone installer."
    }
}

$msiProductCodePattern = '^\{[0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{12}\}$'
$uninstallRegistryRoot = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall"
$uninstallRegistryPattern = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*"
$existingMsiRegistration = $null
if (Test-Path -LiteralPath $uninstallRegistryRoot) {
    $existingMsiRegistration = Get-ItemProperty $uninstallRegistryPattern -ErrorAction Stop |
        Where-Object {
            $_.DisplayName -eq "Code-Codex" -and
            [string]$_.PSChildName -match $msiProductCodePattern -and
            [string]$_.WindowsInstaller -eq "1"
        } |
        Select-Object -First 1
}
if ($null -ne $existingMsiRegistration) {
    throw "Code-Codex is registered with Windows Installer. Uninstall it through Windows Installed apps before using the standalone installer."
}

Publish-CodeCodexProgress 68 "Checking Codex integration" "Validating the official Codex installation and shortcuts."
& $SourceShortcutTool preflight --install-root $InstallRoot --version $Version
if ($LASTEXITCODE -ne 0) {
    throw "Stable Codex could not be validated for Code-Codex integration. No installation files were changed."
}
$script:InstallOperation = "Creating installation directory"
New-Item -ItemType Directory -Path $InstallRoot -Force | Out-Null
$installRootItem = Get-ExistingItem $InstallRoot
if ($null -eq $installRootItem -or -not $installRootItem.PSIsContainer -or (Test-ReparsePoint $installRootItem)) {
    throw "The installation root must be a regular directory."
}
$script:InstallOperation = 'Preparing centralized storage'
$StorageMarkerPath = Join-Path $InstallRoot 'storage-layout.json'
if (Get-ExistingItem $StorageMarkerPath) {
    $null=Assert-CodeCodexRoot $InstallRoot -Owned
    $StorageMarkerBefore = [IO.File]::ReadAllText($StorageMarkerPath)
}
$script:StorageSnapshotTaken = $true
$script:InstallOperation = 'Checking storage replacement capability'
$script:InstallTarget = $InstallRoot
Test-CodeCodexAtomicStorage $InstallRoot { param($phase,$status) Trace-Install ('Storage preflight '+$phase) $status 0 }
Publish-CodeCodexProgress 70 'Migrating existing data' 'Copying settings, verified plugins and logs; keeping original data for recovery.'
# Retain this product marker after an interrupted migration so a retry can resume safely.
Write-AtomicText $StorageMarkerPath '{"schema":1,"product":"Code-Codex","layout":"centralized"}'
Initialize-CodeCodexStorage $InstallRoot
Trace-Install 'storage migration' ('passed; copied=' + $script:MigrationCopied + '; preservedDestination=' + $script:MigrationSkipped)
$script:InstallOperation = "Saving shortcut rollback state"
& $SourceShortcutTool prepare-install --install-root $InstallRoot | Out-Null
if ($LASTEXITCODE -ne 0) { throw "The shortcut rollback state could not be prepared." }
$script:InstallRollbackPrepared = $true
$previousVersionPath = Join-Path $InstallRoot "current-version"
$previousInstallTypePath = Join-Path $InstallRoot "install-type"
if (Test-Path -LiteralPath $previousVersionPath -PathType Leaf) {
    $previousVersionMarker = [IO.File]::ReadAllText($previousVersionPath)
}
if (Test-Path -LiteralPath $previousInstallTypePath -PathType Leaf) {
    $previousInstallTypeMarker = [IO.File]::ReadAllText($previousInstallTypePath)
}
$script:VersionSnapshotTaken = $true

New-Item -ItemType Directory -Path $VersionsRoot -Force | Out-Null
$versionsItem = Get-Item -LiteralPath $VersionsRoot -Force
if (-not $versionsItem.PSIsContainer -or (Test-ReparsePoint $versionsItem)) {
    throw "The versions path must be a regular directory: $VersionsRoot"
}

if (Test-Path -LiteralPath $VersionRoot) {
    Publish-CodeCodexProgress 74 "Verifying application files" "Comparing the installed binaries with this package."
    $versionItem = Get-Item -LiteralPath $VersionRoot -Force
    if (-not $versionItem.PSIsContainer -or (Test-ReparsePoint $versionItem)) {
        throw "The release path must be a regular directory: $VersionRoot"
    }
    foreach ($pair in @(
        @($SourceBinary, (Join-Path $VersionRoot "code-codex.exe")),
        @($SourceRuntimeLauncher, (Join-Path $VersionRoot "CodeCodex.exe"))
    )) {
        if (-not (Test-Path -LiteralPath $pair[1] -PathType Leaf) -or
            (Get-Sha256Hash $pair[0]) -ne (Get-Sha256Hash $pair[1])) {
            throw "Version $Version is already installed with a different payload. Use a new release version."
        }
    }
}
else {
    Publish-CodeCodexProgress 74 "Installing application files" "Copying the Code-Codex binaries into the version folder."
    $stagingVersion = Join-Path $VersionsRoot (".{0}.{1}.tmp" -f $Version, [Guid]::NewGuid().ToString("N"))
    try {
        New-Item -ItemType Directory -Path $stagingVersion | Out-Null
        Copy-Item -LiteralPath $SourceBinary -Destination (Join-Path $stagingVersion "code-codex.exe")
        Copy-Item -LiteralPath $SourceRuntimeLauncher -Destination (Join-Path $stagingVersion "CodeCodex.exe")
        Invoke-InstallFileOperation "Moving version directory" $VersionRoot {
            [IO.Directory]::Move($stagingVersion, $VersionRoot)
        }
        $script:CreatedVersionRoot = $true
    }
    finally {
        if (Test-Path -LiteralPath $stagingVersion) {
            try { Remove-Item -LiteralPath $stagingVersion -Recurse -Force -ErrorAction Stop }
            catch { $script:CleanupIssues += "staging directory cleanup failed" }
        }
    }
}

Publish-CodeCodexProgress 81 "Installing support files" "Updating the launcher, uninstaller, and documentation."
Copy-AtomicFile $SourceShim (Join-Path $InstallRoot "CodeCodex.exe")
Copy-AtomicFile $SourceShortcutTool (Join-Path $InstallRoot "CodeCodex.Shortcut.exe")
Copy-AtomicFile $SourceUninstallerExecutable (Join-Path $InstallRoot "Uninstall-CodeCodex.exe")
Copy-AtomicFile $SourceUninstaller (Join-Path $InstallRoot "Uninstall-CodeCodex.ps1")
Copy-AtomicFile $SourceFinalizer (Join-Path $InstallRoot "Finalize-Uninstall.ps1")
Copy-AtomicFile $SourceBrandIcon (Join-Path $InstallRoot "CodeCodex.Brand.png")

foreach ($documentCopy in $documentCopies) {
    Assert-SafeFileCopy $documentCopy.Source $documentCopy.Destination
    Copy-AtomicFile $documentCopy.Source $documentCopy.Destination
}
if ($installDocumentation) {
    Copy-SafeDocumentTree $sourceDocs $installedDocs
}

Write-AtomicText (Join-Path $InstallRoot "current-version") ($Version + "`n")
Write-AtomicText (Join-Path $InstallRoot "install-type") "portable`n"
Write-AtomicText $StorageMarkerPath '{"schema":1,"product":"Code-Codex","layout":"centralized"}'
New-Item 'HKCU:\Software\CodeCodex' -Force | Out-Null
New-ItemProperty 'HKCU:\Software\CodeCodex' -Name InstallPath -Value $InstallRoot -PropertyType String -Force | Out-Null

Publish-CodeCodexProgress 88 "Registering installation" "Updating the Windows installed-app entry."
# Remove the obsolete sign-in launch entry. The existing Codex or ChatGPT
# shortcut is now the single user-controlled entry point for both the official
# app and Code-Codex.
Remove-ItemProperty `
    -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Run" `
    -Name "CodeCodex" `
    -ErrorAction SilentlyContinue

$uninstallKey = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\CodeCodex"
$previousRegistryEntry = Get-ItemProperty -LiteralPath $uninstallKey -ErrorAction SilentlyContinue
$script:RegistrySnapshotTaken = $true
New-Item -Path $uninstallKey -Force | Out-Null
New-ItemProperty -Path $uninstallKey -Name "DisplayName" -PropertyType String -Value "Code-Codex" -Force | Out-Null
New-ItemProperty -Path $uninstallKey -Name "DisplayVersion" -PropertyType String -Value $Version -Force | Out-Null
New-ItemProperty -Path $uninstallKey -Name "Publisher" -PropertyType String -Value "Code-Codex contributors" -Force | Out-Null
New-ItemProperty -Path $uninstallKey -Name "InstallLocation" -PropertyType String -Value $InstallRoot -Force | Out-Null
New-ItemProperty -Path $uninstallKey -Name "DisplayIcon" -PropertyType String -Value (Join-Path $InstallRoot "Uninstall-CodeCodex.exe") -Force | Out-Null
New-ItemProperty -Path $uninstallKey -Name "UninstallString" -PropertyType String `
    -Value ('"{0}"' -f (Join-Path $InstallRoot "Uninstall-CodeCodex.exe")) -Force | Out-Null
New-ItemProperty -Path $uninstallKey -Name "NoModify" -PropertyType DWord -Value 1 -Force | Out-Null
New-ItemProperty -Path $uninstallKey -Name "NoRepair" -PropertyType DWord -Value 1 -Force | Out-Null

$installedShortcutTool = Join-Path $InstallRoot "CodeCodex.Shortcut.exe"
Publish-CodeCodexProgress 94 "Updating shortcuts" "Linking the Codex desktop shortcut to Code-Codex."
$shortcutResultJson = & $installedShortcutTool install --install-root $InstallRoot --version $Version --preserve-legacy
$shortcutExitCode = $LASTEXITCODE
if ($shortcutExitCode -ne 0) {
    throw "The Codex or ChatGPT desktop shortcut could not be redirected, or the Code-Codex shortcut could not be created (exit code $shortcutExitCode)."
}
$shortcutResult = ($shortcutResultJson -join "`n") | ConvertFrom-Json
$managedShortcut = [string]$shortcutResult.shortcutPath
if (-not $managedShortcut -or -not (Test-Path -LiteralPath $managedShortcut -PathType Leaf)) {
    throw "Code-Codex could not verify the installed desktop shortcut."
}
$script:InstallOperation = "Verifying installed payload and shortcut"
foreach ($pair in @(
    @($SourceBinary, (Join-Path $VersionRoot "code-codex.exe")),
    @($SourceRuntimeLauncher, (Join-Path $VersionRoot "CodeCodex.exe")),
    @($SourceShim, (Join-Path $InstallRoot "CodeCodex.exe")),
    @($SourceShortcutTool, $installedShortcutTool),
    @($SourceUninstallerExecutable, (Join-Path $InstallRoot "Uninstall-CodeCodex.exe"))
)) {
    if (-not (Test-Path -LiteralPath $pair[1] -PathType Leaf) -or
        (Get-Sha256Hash $pair[0]) -ne (Get-Sha256Hash $pair[1])) {
        throw "Installed file verification failed for $([IO.Path]::GetFileName($pair[1]))."
    }
}
if (([IO.File]::ReadAllText($previousVersionPath)).Trim() -ne $Version) {
    throw "The active installed version was not updated."
}
$shortcutStatusJson = & $installedShortcutTool status --install-root $InstallRoot
if ($LASTEXITCODE -ne 0) { throw "The installed shortcut status could not be verified." }
$shortcutStatus = ($shortcutStatusJson -join "`n") | ConvertFrom-Json
if ([string]$shortcutStatus.state -ne "managed" -or
    [string]$shortcutStatus.installedVersion -ne $Version -or
    [string]$shortcutStatus.shortcutPath -ne $managedShortcut) {
    throw "The installed shortcut does not point to the verified version."
}
$script:InstallOperation = "Committing shortcut installation"
& $installedShortcutTool commit-install --install-root $InstallRoot | Out-Null
if ($LASTEXITCODE -ne 0) { throw "The shortcut installation could not be committed." }
$script:InstallRollbackPrepared = $false
$script:InstallCommitted = $true
Publish-CodeCodexProgress 96 "Shortcut ready" "Code-Codex will start from $([IO.Path]::GetFileNameWithoutExtension($managedShortcut))."

$script:VersionRetentionReport = Remove-CodeCodexOldVersions $InstallRoot $Version $previousVersionMarker $script:InstallCommitted
if ($script:VersionRetentionReport.outcome -ne 'passed') {
    Write-Warning 'Some older application versions were retained. See versionRetention in the installation log for details.'
}

$installedCommandLine = Join-Path $VersionRoot "code-codex.exe"
Publish-CodeCodexProgress 98 "Activating Code-Codex" "Refreshing any currently open Codex window."
try {
    if (-not $NoActivate) { Start-Process `
        -FilePath $installedCommandLine `
        -ArgumentList @("activate") `
        -WindowStyle Hidden | Out-Null }
}
catch {
    Write-Warning "Code-Codex was installed, but the currently open Codex window could not be updated automatically: $($_.Exception.Message)"
}

Save-CodeCodexInstallReport 'passed'
Write-Host "Code-Codex managed shortcut: $managedShortcut"
Write-Host "Installed Code-Codex $Version. Open the managed desktop shortcut to start Codex with Code-Codex."
}
catch {
    $failure = $_
    $rollbackIssues = @($script:CleanupIssues)
    if (-not $script:InstallCommitted) {
        if ($script:StorageSnapshotTaken) {
            try {
                if ($null -ne $StorageMarkerBefore) { Write-AtomicText $StorageMarkerPath $StorageMarkerBefore }
                if ($StorageRegistryBefore -and $StorageRegistryBefore.InstallPath) { Set-ItemProperty 'HKCU:\Software\CodeCodex' -Name InstallPath -Value $StorageRegistryBefore.InstallPath }
                else { Remove-ItemProperty 'HKCU:\Software\CodeCodex' -Name InstallPath -ErrorAction SilentlyContinue }
            } catch { $rollbackIssues += 'storage locator rollback failed' }
        }
        if ($script:InstallRollbackPrepared) {
            & $SourceShortcutTool rollback-install --install-root $InstallRoot | Out-Null
            if ($LASTEXITCODE -ne 0) { $rollbackIssues += "shortcut rollback failed" }
        }
        if ($script:VersionSnapshotTaken) {
        foreach ($marker in @(@($previousVersionPath, $previousVersionMarker), @($previousInstallTypePath, $previousInstallTypeMarker))) {
            if (-not $marker[0]) { continue }
            try {
                if ($null -eq $marker[1]) {
                    Remove-Item -LiteralPath $marker[0] -Force -ErrorAction SilentlyContinue
                }
                else {
                    [IO.File]::WriteAllText($marker[0], [string]$marker[1], [Text.UTF8Encoding]::new($false))
                }
            }
            catch { $rollbackIssues += "version marker rollback failed" }
        }
        }
        if ($script:RegistrySnapshotTaken) {
            try {
                if ($null -eq $previousRegistryEntry) {
                    Remove-Item -LiteralPath $uninstallKey -Force -ErrorAction SilentlyContinue
                }
                else {
                    foreach ($name in @('DisplayName', 'DisplayVersion', 'Publisher', 'InstallLocation', 'DisplayIcon', 'UninstallString', 'NoModify', 'NoRepair')) {
                        $property = $previousRegistryEntry.PSObject.Properties[$name]
                        if ($null -eq $property) {
                            Remove-ItemProperty -LiteralPath $uninstallKey -Name $name -ErrorAction SilentlyContinue
                        }
                        else {
                            Set-ItemProperty -LiteralPath $uninstallKey -Name $name -Value $property.Value -ErrorAction Stop
                        }
                    }
                }
            }
            catch { $rollbackIssues += "installed-app registration rollback failed" }
        }
        if ($script:CreatedVersionRoot -and $VersionRoot.StartsWith($VersionsRoot + '\', [StringComparison]::OrdinalIgnoreCase)) {
            try { Remove-Item -LiteralPath $VersionRoot -Recurse -Force -ErrorAction Stop }
            catch { $rollbackIssues += "new version directory cleanup failed" }
        }
    }
    Write-InstallDiagnostic $failure
    Save-CodeCodexInstallReport 'failed'
    if ($rollbackIssues.Count -gt 0) {
        [Console]::Out.WriteLine('CODECODEX_ROLLBACK_ERROR:' + ($rollbackIssues -join '; '))
    }
    exit 1
}
