[CmdletBinding()]
param(
    [switch]$KeepSettings,
    [switch]$PurgeSettings
)

$ErrorActionPreference = "Stop"
$InstallRoot = Join-Path $env:LOCALAPPDATA "Programs\Code-Codex"
$ProgramsRoot = [IO.Path]::GetFullPath((Join-Path $env:LOCALAPPDATA "Programs"))
$AllowedRoot = $ProgramsRoot.TrimEnd([IO.Path]::DirectorySeparatorChar, [IO.Path]::AltDirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar
$InstallFullPath = [IO.Path]::GetFullPath($InstallRoot)
$InstallPrefix = $InstallFullPath.TrimEnd([IO.Path]::DirectorySeparatorChar, [IO.Path]::AltDirectorySeparatorChar) + [IO.Path]::DirectorySeparatorChar
$ShortcutOwnerMarker = "Managed by Code-Codex (code-codex/v1)"
$LegacyShortcutDescription = "Launch Codex Desktop with Code-Codex file preview and editing"

function Publish-CodeCodexProgress([int]$Percent, [string]$Stage, [string]$Detail) {
    if ([string]::IsNullOrWhiteSpace($env:CLE_PROGRESS_STATE_PATH)) { return }
    try {
        $message = [Convert]::ToBase64String(
            [Text.Encoding]::UTF8.GetBytes($Stage + "`n" + $Detail)
        )
        $command = "{0}|progress|{1}|{2}" -f [DateTime]::UtcNow.Ticks, $Percent, $message
        [IO.File]::WriteAllText($env:CLE_PROGRESS_STATE_PATH, $command, [Text.UTF8Encoding]::new($false))
    }
    catch {} # A display failure must not interrupt uninstallation.
}

function Test-ReparsePoint([IO.FileSystemInfo]$Item) {
    return ($Item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0
}

function Get-ExistingItem([string]$Path) {
    return Get-Item -LiteralPath $Path -Force -ErrorAction SilentlyContinue
}

function Test-SamePath([string]$Left, [string]$Right) {
    if ([string]::IsNullOrWhiteSpace($Left) -or [string]::IsNullOrWhiteSpace($Right)) {
        return $false
    }
    try {
        $leftFull = [IO.Path]::GetFullPath($Left).TrimEnd(
            [IO.Path]::DirectorySeparatorChar,
            [IO.Path]::AltDirectorySeparatorChar
        )
        $rightFull = [IO.Path]::GetFullPath($Right).TrimEnd(
            [IO.Path]::DirectorySeparatorChar,
            [IO.Path]::AltDirectorySeparatorChar
        )
        return $leftFull.Equals($rightFull, [StringComparison]::OrdinalIgnoreCase)
    }
    catch {
        return $false
    }
}

function Test-SameProcessIdentity([object]$Expected, [object]$Current) {
    if ($null -eq $Expected -or $null -eq $Current -or
        $null -eq $Expected.CreationDate -or $null -eq $Current.CreationDate) {
        return $false
    }
    return [uint32]$Expected.ProcessId -eq [uint32]$Current.ProcessId -and
        [string]$Expected.Name -ieq [string]$Current.Name -and
        $Expected.CreationDate -eq $Current.CreationDate -and
        (Test-SamePath ([string]$Expected.ExecutablePath) ([string]$Current.ExecutablePath))
}

function Remove-ReparsePoint([IO.FileSystemInfo]$Item) {
    if ($Item.PSIsContainer) {
        [IO.Directory]::Delete($Item.FullName, $false)
    }
    else {
        [IO.File]::Delete($Item.FullName)
    }
}

function Remove-SettingsEntry([string]$Path, [switch]$RegularFileOnly) {
    $item = Get-ExistingItem $Path
    if ($null -eq $item) { return }
    if ($RegularFileOnly -and ((Test-ReparsePoint $item) -or $item.PSIsContainer)) {
        return
    }
    if (Test-ReparsePoint $item) {
        Remove-ReparsePoint $item
    }
    elseif ($item.PSIsContainer) {
        throw "Refusing to recursively remove an unexpected settings directory: $Path"
    }
    else {
        $item.Attributes = [IO.FileAttributes]::Normal
        [IO.File]::Delete($Path)
    }
}

function Remove-VerifiedCodeCodexDesktopShortcut {
    $desktop = [Environment]::GetEnvironmentVariable("CODE_CODEX_DESKTOP")
    if ([string]::IsNullOrWhiteSpace($desktop)) {
        $desktop = [Environment]::GetFolderPath([Environment+SpecialFolder]::DesktopDirectory)
    }
    if ([string]::IsNullOrWhiteSpace($desktop)) { return }

    $shortcutPath = Join-Path $desktop "Code-Codex.lnk"
    $shortcutItem = Get-ExistingItem $shortcutPath
    if ($null -eq $shortcutItem) { return }
    if ($shortcutItem.PSIsContainer -or (Test-ReparsePoint $shortcutItem)) { return }

    try {
        $shell = New-Object -ComObject WScript.Shell
        $shortcut = $shell.CreateShortcut($shortcutPath)
        $targetPath = [string]$shortcut.TargetPath
        $description = [string]$shortcut.Description
        if ([string]::IsNullOrWhiteSpace($targetPath)) { return }

        $targetFullPath = [IO.Path]::GetFullPath($targetPath)
        $expectedLauncher = Join-Path $InstallFullPath "CodeCodex.exe"
        $ownedTarget = (Test-SamePath $targetFullPath $expectedLauncher) -or
            $targetFullPath.StartsWith($InstallPrefix, [StringComparison]::OrdinalIgnoreCase)
        $ownedDescription = $description -eq $ShortcutOwnerMarker -or
            $description -eq $LegacyShortcutDescription

        if ($ownedTarget -and $ownedDescription) {
            $shortcutItem.Attributes = [IO.FileAttributes]::Normal
            [IO.File]::Delete($shortcutPath)
        }
    }
    catch {
        return
    }
}

if (-not $InstallFullPath.StartsWith($AllowedRoot, [StringComparison]::OrdinalIgnoreCase)) {
    throw "Refusing to remove unexpected path: $InstallFullPath"
}
if ($KeepSettings -and $PurgeSettings) {
    throw "-KeepSettings and -PurgeSettings cannot be used together."
}
Publish-CodeCodexProgress 18 "Checking installation" "Verifying the installation path and removal options."

$programsItem = Get-ExistingItem $ProgramsRoot
if ($null -ne $programsItem -and
    (-not $programsItem.PSIsContainer -or (Test-ReparsePoint $programsItem))) {
    throw "Refusing to uninstall through a non-directory or reparse-point Programs path: $ProgramsRoot"
}

$installItem = Get-ExistingItem $InstallFullPath
$processSnapshot = @()
$uninstallerLauncherPid = 0
$finalizerCopy = $null
$finalizerLaunched = $false
$powerShellPath = $null
if ($null -ne $installItem) {
    if (-not $installItem.PSIsContainer -or (Test-ReparsePoint $installItem)) {
        throw "Refusing to uninstall from a non-directory or reparse-point install path: $InstallFullPath"
    }
    $running = @()
    $unverifiedRunning = @()
    Publish-CodeCodexProgress 24 "Checking running processes" "Finding Code-Codex sessions that need to close."
    $processSnapshot = @(Get-CimInstance Win32_Process -ErrorAction Stop)
    foreach ($process in $processSnapshot) {
        $knownProductName = [string]$process.Name -in @(
            "code-codex.exe",
            "CodeCodex.exe"
        )
        if (-not $knownProductName) { continue }
        if ([string]::IsNullOrWhiteSpace([string]$process.ExecutablePath)) {
            $unverifiedRunning += [uint32]$process.ProcessId
            continue
        }
        try {
            $processPath = [IO.Path]::GetFullPath([string]$process.ExecutablePath)
            if ($processPath.StartsWith($InstallPrefix, [StringComparison]::OrdinalIgnoreCase)) {
                $running += [pscustomobject]@{
                    ProcessId = [uint32]$process.ProcessId
                    Name = [string]$process.Name
                    ExecutablePath = $processPath
                    CreationDate = $process.CreationDate
                }
            }
        }
        catch {
            $unverifiedRunning += [uint32]$process.ProcessId
        }
    }
    $unverifiedRunning = @($unverifiedRunning | Sort-Object -Unique)
    if ($unverifiedRunning.Count -gt 0) {
        $unverifiedProcessIds = $unverifiedRunning -join ", "
        throw "A running Code-Codex process could not be verified safely (process IDs: $unverifiedProcessIds). Close Code-Codex, then run the uninstaller again."
    }

    # Retain the process identities for the session launched by Code-Codex.
    # This includes the app server, package guard, and Codex window, but not an
    # unrelated Codex process whose parent chain is outside this launch.
    $ownedDescendants = @()
    $ownedProcessIds = @($running | ForEach-Object { [uint32]$_.ProcessId })
    $frontierProcessIds = @($ownedProcessIds)
    $descendantDepth = 1
    while ($frontierProcessIds.Count -gt 0 -and $descendantDepth -le 32) {
        $children = @(
            $processSnapshot |
                Where-Object {
                    [uint32]$_.ParentProcessId -in $frontierProcessIds -and
                    [uint32]$_.ProcessId -notin $ownedProcessIds
                }
        )
        if ($children.Count -eq 0) { break }

        foreach ($child in $children) {
            $childPath = $null
            if (-not [string]::IsNullOrWhiteSpace([string]$child.ExecutablePath)) {
                try {
                    $childPath = [IO.Path]::GetFullPath([string]$child.ExecutablePath)
                }
                catch {}
            }
            $ownedDescendants += [pscustomobject]@{
                ProcessId = [uint32]$child.ProcessId
                Name = [string]$child.Name
                ExecutablePath = $childPath
                CreationDate = $child.CreationDate
                Depth = $descendantDepth
            }
        }
        $frontierProcessIds = @($children | ForEach-Object { [uint32]$_.ProcessId })
        $ownedProcessIds += $frontierProcessIds
        $descendantDepth++
    }

    # A desktop user should not have to discover and close hidden launcher and
    # service processes before uninstalling. Stop only product executables that
    # are still verified inside this installation, checking the identity again
    # immediately before termination to narrow the PID-reuse race.
    $running = @(
        $running |
            Sort-Object `
                @{ Expression = { if ($_.Name -ieq "CodeCodex.exe") { 0 } else { 1 } } }, `
                ProcessId
    )
    Publish-CodeCodexProgress 31 "Closing Code-Codex" "Stopping verified Code-Codex processes before removal."
    $stoppedProcessIds = @()
    foreach ($runningProcess in $running) {
        $currentProcess = Get-CimInstance `
            Win32_Process `
            -Filter ("ProcessId = {0}" -f [uint32]$runningProcess.ProcessId) `
            -ErrorAction Stop
        if ($null -eq $currentProcess) { continue }

        if (-not (Test-SameProcessIdentity $runningProcess $currentProcess)) {
            # The launcher may have already closed this child. Never stop a
            # replacement process that reused the same PID.
            continue
        }

        try {
            Stop-Process -Id ([int]$runningProcess.ProcessId) -Force -ErrorAction Stop
        }
        catch {
            $stopError = $_.Exception.Message
            $afterStopFailure = Get-CimInstance `
                Win32_Process `
                -Filter ("ProcessId = {0}" -f [uint32]$runningProcess.ProcessId) `
                -ErrorAction Stop
            if (Test-SameProcessIdentity $runningProcess $afterStopFailure) {
                throw "Code-Codex could not be stopped automatically: $stopError"
            }
            continue
        }
        $stoppedProcessIds += [int]$runningProcess.ProcessId
    }
    $stoppedProcessIds = @($stoppedProcessIds | Sort-Object -Unique)
    if ($stoppedProcessIds.Count -gt 0) {
        Wait-Process -Id $stoppedProcessIds -Timeout 15 -ErrorAction SilentlyContinue
        $remaining = @(
            $running |
                Where-Object {
                    $_.ProcessId -in $stoppedProcessIds -and
                    (Test-SameProcessIdentity $_ (Get-CimInstance `
                        Win32_Process `
                        -Filter ("ProcessId = {0}" -f [uint32]$_.ProcessId) `
                        -ErrorAction Stop))
                }
        )
        if ($remaining.Count -gt 0) {
            throw "Code-Codex could not be stopped automatically. Restart Windows, then run the uninstaller again."
        }
    }

    # Stop the verified descendant session from the leaves inward. Closing the
    # Codex package processes lets the package guard exit, while leaving the
    # installed stable Codex application itself untouched on disk.
    $stoppedDescendantIds = @()
    foreach ($ownedDescendant in @(
        $ownedDescendants |
            Sort-Object `
                @{ Expression = { $_.Depth }; Descending = $true }, `
                ProcessId
    )) {
        $currentDescendant = Get-CimInstance `
            Win32_Process `
            -Filter ("ProcessId = {0}" -f [uint32]$ownedDescendant.ProcessId) `
            -ErrorAction Stop
        if ($null -eq $currentDescendant) { continue }
        if (-not (Test-SameProcessIdentity $ownedDescendant $currentDescendant)) {
            continue
        }

        try {
            Stop-Process -Id ([int]$ownedDescendant.ProcessId) -Force -ErrorAction Stop
            $stoppedDescendantIds += [int]$ownedDescendant.ProcessId
        }
        catch {
            $stopError = $_.Exception.Message
            $afterStopFailure = Get-CimInstance `
                Win32_Process `
                -Filter ("ProcessId = {0}" -f [uint32]$ownedDescendant.ProcessId) `
                -ErrorAction Stop
            if (Test-SameProcessIdentity $ownedDescendant $afterStopFailure) {
                throw "The Code-Codex session could not be closed automatically: $stopError"
            }
        }
    }
    $stoppedDescendantIds = @($stoppedDescendantIds | Sort-Object -Unique)
    if ($stoppedDescendantIds.Count -gt 0) {
        Wait-Process -Id $stoppedDescendantIds -Timeout 15 -ErrorAction SilentlyContinue
    }

    $processSnapshot = @(Get-CimInstance Win32_Process -ErrorAction Stop)

    $currentProcessRecord = $processSnapshot |
        Where-Object { [uint32]$_.ProcessId -eq [uint32]$PID } |
        Select-Object -First 1
    if ($null -ne $currentProcessRecord) {
        $parentProcessRecord = $processSnapshot |
            Where-Object {
                [uint32]$_.ProcessId -eq [uint32]$currentProcessRecord.ParentProcessId
            } |
            Select-Object -First 1
        if ($null -ne $parentProcessRecord -and
            [string]$parentProcessRecord.Name -ieq "Uninstall-CodeCodex.exe") {
            $expectedUninstaller = Join-Path $InstallFullPath "Uninstall-CodeCodex.exe"
            if ([string]::IsNullOrWhiteSpace([string]$parentProcessRecord.ExecutablePath) -or
                (Test-SamePath ([string]$parentProcessRecord.ExecutablePath) $expectedUninstaller)) {
                $uninstallerLauncherPid = [int]$parentProcessRecord.ProcessId
            }
        }
    }

    Publish-CodeCodexProgress 39 "Preparing file removal" "Verifying the separate removal helper."
    $finalizerSource = Join-Path $InstallFullPath "Finalize-Uninstall.ps1"
    $finalizerItem = Get-ExistingItem $finalizerSource
    if ($null -eq $finalizerItem) {
        throw "Uninstall finalizer is missing: $finalizerSource"
    }
    if ($finalizerItem.PSIsContainer -or (Test-ReparsePoint $finalizerItem)) {
        throw "Refusing to execute a non-file or reparse-point uninstall finalizer: $finalizerSource"
    }

    $systemDirectory = [Environment]::GetFolderPath([Environment+SpecialFolder]::System)
    $powerShellPath = [IO.Path]::GetFullPath((Join-Path $systemDirectory "WindowsPowerShell\v1.0\powershell.exe"))
    $systemDirectoryFull = [IO.Path]::GetFullPath($systemDirectory) + [IO.Path]::DirectorySeparatorChar
    $powerShellItem = Get-ExistingItem $powerShellPath
    if (-not $powerShellPath.StartsWith($systemDirectoryFull, [StringComparison]::OrdinalIgnoreCase) -or
        $null -eq $powerShellItem -or $powerShellItem.PSIsContainer -or
        (Test-ReparsePoint $powerShellItem)) {
        throw "Trusted Windows PowerShell executable was not found."
    }

    $finalizerCopy = Join-Path $env:TEMP ("CodeCodex-Uninstall-{0}.ps1" -f [Guid]::NewGuid().ToString("N"))
    try {
        Copy-Item -LiteralPath $finalizerSource -Destination $finalizerCopy
        $finalizerCopyItem = Get-ExistingItem $finalizerCopy
        if ($null -eq $finalizerCopyItem -or $finalizerCopyItem.PSIsContainer -or
            (Test-ReparsePoint $finalizerCopyItem) -or
            (Get-FileHash -LiteralPath $finalizerSource -Algorithm SHA256).Hash -ne
                (Get-FileHash -LiteralPath $finalizerCopy -Algorithm SHA256).Hash) {
            throw "The temporary uninstall finalizer could not be verified."
        }
    }
    catch {
        Remove-Item -LiteralPath $finalizerCopy -Force -ErrorAction SilentlyContinue
        throw
    }
}

if ($null -eq $installItem) {
    Write-Host "Code-Codex is not installed."
    return
}

try {
    # A physical uninstaller is also shipped by the MSI. Delegate from the
    # verified temporary helper so Windows Installer can remove this process.
    $installTypePath = Join-Path $InstallFullPath "install-type"
    $installTypeItem = Get-ExistingItem $installTypePath
    if ($null -ne $installTypeItem -and
        ($installTypeItem.PSIsContainer -or (Test-ReparsePoint $installTypeItem))) {
        throw "Refusing to read a non-file or reparse-point installation ownership marker: $installTypePath"
    }
    if ($null -ne $installTypeItem -and
        (Get-Content -LiteralPath $installTypePath -Raw -Encoding UTF8).Trim() -eq "msi") {
        Publish-CodeCodexProgress 48 "Handing off to Windows Installer" "The removal window will continue after this step closes."
        $msiProductCodePattern = '^\{[0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{12}\}$'
        $productCandidates = @(
            Get-ItemProperty `
                    "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*" `
                    -ErrorAction Stop |
                Where-Object {
                    $_.DisplayName -eq "Code-Codex" -and
                    [string]$_.PSChildName -match $msiProductCodePattern -and
                    [string]$_.WindowsInstaller -eq "1"
                }
        )
        $matchingProducts = @(
            $productCandidates |
                Where-Object { Test-SamePath ([string]$_.InstallLocation) $InstallFullPath }
        )
        if ($matchingProducts.Count -eq 0) {
            throw "The Windows Installer product registration for this install location could not be found."
        }
        if ($matchingProducts.Count -ne 1) {
            throw "Multiple Windows Installer product registrations refer to this install location; repair or remove the conflicting registrations before uninstalling."
        }
        $product = $matchingProducts[0]

        $delegateArguments = @(
            "-NoProfile",
            "-ExecutionPolicy", "Bypass",
            "-File", ('"{0}"' -f $finalizerCopy),
            "-InstallRoot", ('"{0}"' -f $InstallFullPath),
            "-ParentPid", $PID,
            "-MsiProductCode", ('"{0}"' -f [string]$product.PSChildName)
        )
        if ($uninstallerLauncherPid -gt 0) {
            $delegateArguments += @("-LauncherPid", $uninstallerLauncherPid)
        }
        Start-Process -FilePath $powerShellPath -WindowStyle Hidden -ArgumentList $delegateArguments
        $finalizerLaunched = $true
        Write-Host "CODE_CODEX_UNINSTALL_DELEGATED"
        Write-Host "Windows Installer will remove Code-Codex after this window closes."
        return
    }

$shortcutTool = Join-Path $InstallFullPath "CodeCodex.Shortcut.exe"
Publish-CodeCodexProgress 45 "Restoring desktop shortcuts" "Removing Code-Codex links and restoring the official Codex shortcut."
$shortcutToolItem = Get-ExistingItem $shortcutTool
if ($null -eq $shortcutToolItem -or $shortcutToolItem.PSIsContainer -or (Test-ReparsePoint $shortcutToolItem)) {
    throw "The verified shortcut restoration tool is missing. No files were removed."
}
Remove-VerifiedCodeCodexDesktopShortcut
& $shortcutTool restore --install-root $InstallFullPath
if ($LASTEXITCODE -ne 0) {
    throw "The Codex, ChatGPT, or Code-Codex desktop shortcut could not be restored or removed. No Code-Codex files were removed."
}
Remove-VerifiedCodeCodexDesktopShortcut

Remove-ItemProperty `
    -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Run" `
    -Name "CodeCodex" `
    -ErrorAction SilentlyContinue

if (-not $KeepSettings -or $PurgeSettings) {
    Publish-CodeCodexProgress 49 "Cleaning settings" "Removing Code-Codex preferences selected for removal."
    $settingsRoot = [IO.Path]::GetFullPath((Join-Path $env:LOCALAPPDATA "CodeCodex"))
    $allowedLocal = [IO.Path]::GetFullPath($env:LOCALAPPDATA) + [IO.Path]::DirectorySeparatorChar
    if (-not $settingsRoot.StartsWith($allowedLocal, [StringComparison]::OrdinalIgnoreCase)) {
        throw "Refusing to remove unexpected settings path: $settingsRoot"
    }
    $settingsItem = Get-ExistingItem $settingsRoot
    if ($null -ne $settingsItem) {
        if (-not $settingsItem.PSIsContainer) {
            throw "Refusing to remove a non-directory settings path: $settingsRoot"
        }
        if (Test-ReparsePoint $settingsItem) {
            Remove-ReparsePoint $settingsItem
        }
        else {
            foreach ($settingsName in @("settings.json", "settings.json.tmp")) {
                $settingsFile = Join-Path $settingsRoot $settingsName
                Remove-SettingsEntry $settingsFile
            }
            $crashOrphanPattern = [regex]::new(
                '^\.settings\.json\.[A-Za-z0-9]{16}\.tmp$',
                [Text.RegularExpressions.RegexOptions]::CultureInvariant
            )
            $crashOrphanPaths = @(
                [IO.Directory]::EnumerateFileSystemEntries(
                    $settingsRoot,
                    ".settings.json.*.tmp",
                    [IO.SearchOption]::TopDirectoryOnly
                ) | Select-Object -First 64
            )
            foreach ($crashOrphanPath in $crashOrphanPaths) {
                if ($crashOrphanPattern.IsMatch([IO.Path]::GetFileName($crashOrphanPath))) {
                    Remove-SettingsEntry $crashOrphanPath -RegularFileOnly
                }
            }
            $verifiedSettings = Get-ExistingItem $settingsRoot
            if ($null -ne $verifiedSettings -and
                -not (Test-ReparsePoint $verifiedSettings) -and
                $verifiedSettings.PSIsContainer -and
                @(Get-ChildItem -LiteralPath $settingsRoot -Force).Count -eq 0) {
                [IO.Directory]::Delete($settingsRoot, $false)
            }
        }
    }
}

$finalizerArguments = @(
    "-NoProfile",
    "-ExecutionPolicy", "Bypass",
    "-File", ('"{0}"' -f $finalizerCopy),
    "-InstallRoot", ('"{0}"' -f $InstallFullPath),
    "-ParentPid", $PID
)
if ($uninstallerLauncherPid -gt 0) {
    $finalizerArguments += @("-LauncherPid", $uninstallerLauncherPid)
}
Start-Process -FilePath $powerShellPath -WindowStyle Hidden -ArgumentList $finalizerArguments
$finalizerLaunched = $true
Publish-CodeCodexProgress 54 "Handing off file removal" "The removal window will continue after this step closes."
Write-Host "CODE_CODEX_UNINSTALL_DELEGATED"

Write-Host "The Codex or ChatGPT desktop shortcut was restored, or the Code-Codex shortcut was removed. Code-Codex will be removed after this window closes."
}
catch {
    if (-not $finalizerLaunched -and
        -not [string]::IsNullOrWhiteSpace([string]$finalizerCopy)) {
        Remove-Item -LiteralPath $finalizerCopy -Force -ErrorAction SilentlyContinue
    }
    throw
}
