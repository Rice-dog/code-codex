# Third-party software

Code-Codex is independently implemented and does not copy, unpack, or
redistribute Codex Desktop application code or assets.

This inventory is generated from the x86_64-pc-windows-msvc production Cargo dependency graph and the
locked embedded-UI build toolchain. The Rust crates below can be linked into the
distributed executable. Their verbatim license and notice files are shipped in
`THIRD_PARTY_LICENSES.txt` and are identified by content hash.

## Rust dependencies linked into the executable

| Package | Version | Declared license | Source | License text IDs |
|---|---:|---|---|---|
| aho-corasick | 1.1.4 | Unlicense OR MIT | https://github.com/BurntSushi/aho-corasick | `154c1af2b38e25e5`, `65314a6c96683f76`, `ca2abdf695884c77` |
| ambient-authority | 0.0.2 | Apache-2.0 WITH LLVM-exception OR Apache-2.0 OR MIT | https://github.com/sunfishcode/ambient-authority | `23823edf263108ef`, `30fefc3a7d6a0041`, `769f80b5bcb42ed0`, `b6ca90f6c89944eb` |
| anstream | 1.0.0 | MIT OR Apache-2.0 | https://github.com/rust-cli/anstyle.git | `4498464c2864825d`, `c5accbbd8546e94c` |
| anstyle | 1.0.14 | MIT OR Apache-2.0 | https://github.com/rust-cli/anstyle.git | `4498464c2864825d`, `c5accbbd8546e94c` |
| anstyle-parse | 1.0.0 | MIT OR Apache-2.0 | https://github.com/rust-cli/anstyle.git | `4498464c2864825d`, `c5accbbd8546e94c` |
| anstyle-query | 1.1.5 | MIT OR Apache-2.0 | https://github.com/rust-cli/anstyle.git | `4498464c2864825d`, `c5accbbd8546e94c` |
| anstyle-wincon | 3.0.11 | MIT OR Apache-2.0 | https://github.com/rust-cli/anstyle.git | `4498464c2864825d`, `c5accbbd8546e94c` |
| async-trait | 0.1.91 | MIT OR Apache-2.0 | https://github.com/dtolnay/async-trait | `30fefc3a7d6a0041`, `95bd3988beee069f` |
| atomic-waker | 1.1.2 | Apache-2.0 OR MIT | https://github.com/smol-rs/atomic-waker | `20746cc8a2fdc9ca`, `30fefc3a7d6a0041`, `769f80b5bcb42ed0` |
| base64 | 0.22.1 | MIT OR Apache-2.0 | https://github.com/marshallpierce/rust-base64 | `6a8da4c78c729176`, `769f80b5bcb42ed0` |
| bitflags | 1.3.2 | MIT OR Apache-2.0 | https://github.com/bitflags/bitflags | `14435fbcd271e278`, `769f80b5bcb42ed0` |
| bitflags | 2.13.1 | MIT OR Apache-2.0 | https://github.com/bitflags/bitflags | `14435fbcd271e278`, `769f80b5bcb42ed0` |
| block-buffer | 0.10.4 | MIT OR Apache-2.0 | https://github.com/RustCrypto/utils | `59013a5c8d3a19c2`, `5ff5253f2cb9347c` |
| bstr | 1.13.0 | MIT OR Apache-2.0 | https://github.com/BurntSushi/bstr | `769f80b5bcb42ed0`, `8649bf6c5eca0205`, `ffea24dba8d2d373` |
| bytes | 1.12.1 | MIT | https://github.com/tokio-rs/bytes | `51f778ffff2c0705` |
| cap-fs-ext | 4.0.2 | Apache-2.0 WITH LLVM-exception OR Apache-2.0 OR MIT | https://github.com/bytecodealliance/cap-std | `23823edf263108ef`, `30fefc3a7d6a0041`, `769f80b5bcb42ed0`, `d47c2d469d602bb2` |
| cap-primitives | 4.0.2 | Apache-2.0 WITH LLVM-exception OR Apache-2.0 OR MIT | https://github.com/bytecodealliance/cap-std | `226fc6da9df7de76`, `23823edf263108ef`, `30fefc3a7d6a0041`, `769f80b5bcb42ed0` |
| cc | 1.3.0 | MIT OR Apache-2.0 | https://github.com/rust-lang/cc-rs | `769f80b5bcb42ed0`, `84e1bbfebd74e419` |
| cfg-if | 1.0.4 | MIT OR Apache-2.0 | https://github.com/rust-lang/cfg-if | `769f80b5bcb42ed0`, `84e1bbfebd74e419` |
| clap | 4.6.3 | MIT OR Apache-2.0 | https://github.com/clap-rs/clap | `4498464c2864825d`, `c5accbbd8546e94c` |
| clap_builder | 4.6.2 | MIT OR Apache-2.0 | https://github.com/clap-rs/clap | `4498464c2864825d`, `c5accbbd8546e94c` |
| clap_derive | 4.6.3 | MIT OR Apache-2.0 | https://github.com/clap-rs/clap | `4498464c2864825d`, `c5accbbd8546e94c` |
| clap_lex | 1.1.0 | MIT OR Apache-2.0 | https://github.com/clap-rs/clap | `4498464c2864825d`, `c5accbbd8546e94c` |
| colorchoice | 1.0.5 | MIT OR Apache-2.0 | https://github.com/rust-cli/anstyle.git | `4498464c2864825d`, `c5accbbd8546e94c` |
| constant_time_eq | 0.4.2 | CC0-1.0 OR MIT-0 OR Apache-2.0 | https://github.com/cesarb/constant_time_eq | `6d489af6292662d9`, `95bd3988beee069f`, `ee3c852dd133c6ca` |
| cpufeatures | 0.2.17 | MIT OR Apache-2.0 | https://github.com/RustCrypto/utils | `59013a5c8d3a19c2`, `6334e52844d698f5` |
| crossbeam-deque | 0.8.7 | MIT OR Apache-2.0 | https://github.com/crossbeam-rs/crossbeam | `5a7d13c6710cdec2`, `769f80b5bcb42ed0` |
| crossbeam-epoch | 0.9.20 | MIT OR Apache-2.0 | https://github.com/crossbeam-rs/crossbeam | `5a7d13c6710cdec2`, `769f80b5bcb42ed0` |
| crossbeam-utils | 0.8.22 | MIT OR Apache-2.0 | https://github.com/crossbeam-rs/crossbeam | `5a7d13c6710cdec2`, `769f80b5bcb42ed0` |
| crypto-common | 0.1.7 | MIT OR Apache-2.0 | https://github.com/RustCrypto/traits | `59013a5c8d3a19c2`, `692b1604961dd580` |
| data-encoding | 2.11.0 | MIT | https://github.com/ia0/data-encoding | `9db9de9edfd0ae7c` |
| digest | 0.10.7 | MIT OR Apache-2.0 | https://github.com/RustCrypto/traits | `59013a5c8d3a19c2`, `9c5127ab88e8f55b` |
| directories | 6.0.0 | MIT OR Apache-2.0 | https://github.com/soc/directories-rs | `533e8a72a5904b85`, `96bb3c3b6301e91a` |
| dirs-sys | 0.5.0 | MIT OR Apache-2.0 | https://github.com/dirs-dev/dirs-sys-rs | `96bb3c3b6301e91a`, `f25a5b606859d4fa` |
| displaydoc | 0.2.6 | MIT OR Apache-2.0 | https://github.com/yaahc/displaydoc | `30fefc3a7d6a0041`, `769f80b5bcb42ed0` |
| dunce | 1.0.5 | CC0-1.0 OR MIT-0 OR Apache-2.0 | https://gitlab.com/kornelski/dunce | `6d489af6292662d9` |
| embed-resource | 3.0.11 | MIT | https://github.com/nabijaczleweli/rust-embed-resource | `c4be15bd543af192` |
| equivalent | 1.0.2 | Apache-2.0 OR MIT | https://github.com/indexmap-rs/equivalent | `4428cd87371acbd4`, `769f80b5bcb42ed0` |
| fastrand | 2.5.0 | Apache-2.0 OR MIT | https://github.com/smol-rs/fastrand | `30fefc3a7d6a0041`, `769f80b5bcb42ed0` |
| find-msvc-tools | 0.1.9 | MIT OR Apache-2.0 | https://github.com/rust-lang/cc-rs | `769f80b5bcb42ed0`, `84e1bbfebd74e419` |
| form_urlencoded | 1.2.2 | MIT OR Apache-2.0 | https://github.com/servo/rust-url | `33ed9a8ecf556f16`, `769f80b5bcb42ed0` |
| fs-set-times | 0.20.3 | Apache-2.0 WITH LLVM-exception OR Apache-2.0 OR MIT | https://github.com/bytecodealliance/fs-set-times | `23823edf263108ef`, `30fefc3a7d6a0041`, `769f80b5bcb42ed0`, `8b6ab48f07c0e247` |
| futures | 0.3.33 | MIT OR Apache-2.0 | https://github.com/rust-lang/futures-rs | `b420d8add23b5cf7`, `ca1991cda75e24b3` |
| futures-channel | 0.3.33 | MIT OR Apache-2.0 | https://github.com/rust-lang/futures-rs | `b420d8add23b5cf7`, `ca1991cda75e24b3` |
| futures-core | 0.3.33 | MIT OR Apache-2.0 | https://github.com/rust-lang/futures-rs | `b420d8add23b5cf7`, `ca1991cda75e24b3` |
| futures-executor | 0.3.33 | MIT OR Apache-2.0 | https://github.com/rust-lang/futures-rs | `b420d8add23b5cf7`, `ca1991cda75e24b3` |
| futures-io | 0.3.33 | MIT OR Apache-2.0 | https://github.com/rust-lang/futures-rs | `b420d8add23b5cf7`, `ca1991cda75e24b3` |
| futures-macro | 0.3.33 | MIT OR Apache-2.0 | https://github.com/rust-lang/futures-rs | `b420d8add23b5cf7`, `ca1991cda75e24b3` |
| futures-sink | 0.3.33 | MIT OR Apache-2.0 | https://github.com/rust-lang/futures-rs | `b420d8add23b5cf7`, `ca1991cda75e24b3` |
| futures-task | 0.3.33 | MIT OR Apache-2.0 | https://github.com/rust-lang/futures-rs | `b420d8add23b5cf7`, `ca1991cda75e24b3` |
| futures-util | 0.3.33 | MIT OR Apache-2.0 | https://github.com/rust-lang/futures-rs | `b420d8add23b5cf7`, `ca1991cda75e24b3` |
| generic-array | 0.14.7 | MIT | https://github.com/fizyk20/generic-array.git | `ad4fcfaf8d5b12b9` |
| getrandom | 0.2.17 | MIT OR Apache-2.0 | https://github.com/rust-random/getrandom | `2f7ce0f0ada1987b`, `478d530cbce79fc1` |
| getrandom | 0.3.4 | MIT OR Apache-2.0 | https://github.com/rust-random/getrandom | `2f7ce0f0ada1987b`, `73af2019a565c0e6` |
| getrandom | 0.4.3 | MIT OR Apache-2.0 | https://github.com/rust-random/getrandom | `2f7ce0f0ada1987b`, `94b1870d380ccf53` |
| globset | 0.4.19 | Unlicense OR MIT | https://github.com/BurntSushi/ripgrep/tree/master/crates/globset | `154c1af2b38e25e5`, `65314a6c96683f76`, `ca2abdf695884c77` |
| hashbrown | 0.17.1 | MIT OR Apache-2.0 | https://github.com/rust-lang/hashbrown | `769f80b5bcb42ed0`, `ae9791f02f2bbe0c` |
| heck | 0.5.0 | MIT OR Apache-2.0 | https://github.com/withoutboats/heck | `033a9383ff21d1e4`, `769f80b5bcb42ed0` |
| http | 1.4.2 | MIT OR Apache-2.0 | https://github.com/hyperium/http | `a7e117f398da45a0`, `f47894ff9c86dc7e` |
| http-body | 1.1.0 | MIT | https://github.com/hyperium/http-body | `57f841bc9767b5b8` |
| http-body-util | 0.1.4 | MIT | https://github.com/hyperium/http-body | `57f841bc9767b5b8` |
| httparse | 1.10.1 | MIT OR Apache-2.0 | https://github.com/seanmonstar/httparse | `769f80b5bcb42ed0`, `8502803cebb30a72` |
| hyper | 1.11.0 | MIT | https://github.com/hyperium/hyper | `05f344491a7d18e1` |
| hyper-rustls | 0.27.9 | Apache-2.0 OR ISC OR MIT | https://github.com/rustls/hyper-rustls | `769f80b5bcb42ed0`, `a3320aa8d192a02c`, `af6da3f3f6b4929e` |
| hyper-util | 0.1.20 | MIT | https://github.com/hyperium/hyper-util | `e7d622e4783e8c97` |
| icu_collections | 2.1.1 | Unicode-3.0 | https://github.com/unicode-org/icu4x | `cde87abe221f413f` |
| icu_locale_core | 2.1.1 | Unicode-3.0 | https://github.com/unicode-org/icu4x | `cde87abe221f413f` |
| icu_normalizer | 2.1.1 | Unicode-3.0 | https://github.com/unicode-org/icu4x | `cde87abe221f413f` |
| icu_normalizer_data | 2.1.1 | Unicode-3.0 | https://github.com/unicode-org/icu4x | `cde87abe221f413f` |
| icu_properties | 2.1.2 | Unicode-3.0 | https://github.com/unicode-org/icu4x | `cde87abe221f413f` |
| icu_properties_data | 2.1.2 | Unicode-3.0 | https://github.com/unicode-org/icu4x | `cde87abe221f413f` |
| icu_provider | 2.1.1 | Unicode-3.0 | https://github.com/unicode-org/icu4x | `cde87abe221f413f` |
| idna | 1.1.0 | MIT OR Apache-2.0 | https://github.com/servo/rust-url/ | `769f80b5bcb42ed0`, `7a8093fb4a93f23e` |
| idna_adapter | 1.2.1 | Apache-2.0 OR MIT | https://github.com/hsivonen/idna_adapter | `0d8a0aecbcbaf057`, `769f80b5bcb42ed0` |
| ignore | 0.4.30 | Unlicense OR MIT | https://github.com/BurntSushi/ripgrep/tree/master/crates/ignore | `154c1af2b38e25e5`, `65314a6c96683f76`, `ca2abdf695884c77` |
| indexmap | 2.14.0 | Apache-2.0 OR MIT | https://github.com/indexmap-rs/indexmap | `4f2ac128e429d964`, `769f80b5bcb42ed0` |
| io-extras | 0.19.0 | Apache-2.0 WITH LLVM-exception OR Apache-2.0 OR MIT | https://github.com/sunfishcode/io-extras | `0121f38fa0e3fc83`, `23823edf263108ef`, `30fefc3a7d6a0041`, `769f80b5bcb42ed0` |
| io-lifetimes | 2.0.4 | Apache-2.0 WITH LLVM-exception OR Apache-2.0 OR MIT | https://github.com/sunfishcode/io-lifetimes | `23823edf263108ef`, `30fefc3a7d6a0041`, `769f80b5bcb42ed0`, `ced9d1e3612fb118` |
| io-lifetimes | 3.0.1 | Apache-2.0 WITH LLVM-exception OR Apache-2.0 OR MIT | https://github.com/sunfishcode/io-lifetimes | `23823edf263108ef`, `30fefc3a7d6a0041`, `769f80b5bcb42ed0`, `ced9d1e3612fb118` |
| ipnet | 2.12.0 | MIT OR Apache-2.0 | https://github.com/krisprice/ipnet | `66b593f9d3287f8e`, `c935506fff2ef821` |
| is_terminal_polyfill | 1.70.2 | MIT OR Apache-2.0 | https://github.com/polyfill-rs/is_terminal_polyfill | `4498464c2864825d`, `c5accbbd8546e94c` |
| itoa | 1.0.18 | MIT OR Apache-2.0 | https://github.com/dtolnay/itoa | `30fefc3a7d6a0041`, `95bd3988beee069f` |
| known-folders | 1.4.2 | Apache-2.0 OR MIT | https://github.com/artichoke/known-folders-rs | `58d1e17ffe5109a7`, `bb07e656327e18c0` |
| lazy_static | 1.5.0 | MIT OR Apache-2.0 | https://github.com/rust-lang-nursery/lazy-static.rs | `769f80b5bcb42ed0`, `9e0027807b0c548a` |
| libc | 0.2.188 | MIT OR Apache-2.0 | https://github.com/rust-lang/libc | `95bd3988beee069f`, `c96302294382bf16` |
| litemap | 0.8.2 | Unicode-3.0 | https://github.com/unicode-org/icu4x | `cde87abe221f413f` |
| log | 0.4.33 | MIT OR Apache-2.0 | https://github.com/rust-lang/log | `14435fbcd271e278`, `769f80b5bcb42ed0` |
| matchers | 0.2.0 | MIT | https://github.com/hawkw/matchers | `2aca90f05dbbee76` |
| maybe-owned | 0.3.4 | MIT OR Apache-2.0 | https://github.com/rustonaut/maybe-owned | `ace289579c42b749`, `e2670eceabfb1888` |
| memchr | 2.8.3 | Unlicense OR MIT | https://github.com/BurntSushi/memchr | `154c1af2b38e25e5`, `65314a6c96683f76`, `ca2abdf695884c77` |
| mio | 1.2.2 | MIT | https://github.com/tokio-rs/mio | `c804065b0956d00a` |
| notify | 8.2.0 | CC0-1.0 | https://github.com/notify-rs/notify.git | `3b9a96c5f74727eb` |
| notify-types | 2.1.0 | MIT OR Apache-2.0 | https://github.com/notify-rs/notify.git | `4b2af3889ac2bda6`, `97915bf084b82be7` |
| nu-ansi-term | 0.50.3 | MIT | https://github.com/nushell/nu-ansi-term | `b03a9c03f816ac01` |
| once_cell | 1.21.4 | MIT OR Apache-2.0 | https://github.com/matklad/once_cell | `30fefc3a7d6a0041`, `769f80b5bcb42ed0` |
| once_cell_polyfill | 1.70.2 | MIT OR Apache-2.0 | https://github.com/polyfill-rs/once_cell_polyfill | `4498464c2864825d`, `c5accbbd8546e94c` |
| option-ext | 0.2.0 | MPL-2.0 | https://github.com/soc/option-ext.git | `fb72181dd02473b6` |
| percent-encoding | 2.3.2 | MIT OR Apache-2.0 | https://github.com/servo/rust-url/ | `769f80b5bcb42ed0`, `7a8093fb4a93f23e` |
| pin-project-lite | 0.2.17 | Apache-2.0 OR MIT | https://github.com/taiki-e/pin-project-lite | `0cec06e0e55fbc3d`, `30fefc3a7d6a0041` |
| potential_utf | 0.1.5 | Unicode-3.0 | https://github.com/unicode-org/icu4x | `cde87abe221f413f` |
| ppv-lite86 | 0.2.21 | MIT OR Apache-2.0 | https://github.com/cryptocorrosion/cryptocorrosion | `7f3b9b35f7dbda19`, `b2a541f10560a218` |
| proc-macro2 | 1.0.107 | MIT OR Apache-2.0 | https://github.com/dtolnay/proc-macro2 | `30fefc3a7d6a0041`, `95bd3988beee069f` |
| process-wrap | 8.2.1 | Apache-2.0 OR MIT | https://github.com/watchexec/process-wrap | `30fefc3a7d6a0041`, `7b09692694e8f8e3`, `95bd3988beee069f` |
| quote | 1.0.47 | MIT OR Apache-2.0 | https://github.com/dtolnay/quote | `30fefc3a7d6a0041`, `95bd3988beee069f` |
| rand | 0.8.7 | MIT OR Apache-2.0 | https://github.com/rust-random/rand | `2411d70acb18e15a`, `6508cf9942b42595`, `cc367a7134c2b07d` |
| rand | 0.9.5 | MIT OR Apache-2.0 | https://github.com/rust-random/rand | `2411d70acb18e15a`, `6508cf9942b42595`, `cc367a7134c2b07d` |
| rand_chacha | 0.3.1 | MIT OR Apache-2.0 | https://github.com/rust-random/rand | `2411d70acb18e15a`, `2f7ce0f0ada1987b`, `cc367a7134c2b07d` |
| rand_chacha | 0.9.0 | MIT OR Apache-2.0 | https://github.com/rust-random/rand | `2411d70acb18e15a`, `6508cf9942b42595`, `cc367a7134c2b07d` |
| rand_core | 0.6.4 | MIT OR Apache-2.0 | https://github.com/rust-random/rand | `2411d70acb18e15a`, `60fd4b5e1281706d`, `cc367a7134c2b07d` |
| rand_core | 0.9.5 | MIT OR Apache-2.0 | https://github.com/rust-random/rand | `2411d70acb18e15a`, `60fd4b5e1281706d`, `cc367a7134c2b07d` |
| regex-automata | 0.4.16 | MIT OR Apache-2.0 | https://github.com/rust-lang/regex | `14435fbcd271e278`, `769f80b5bcb42ed0` |
| regex-syntax | 0.8.11 | MIT OR Apache-2.0 | https://github.com/rust-lang/regex | `14435fbcd271e278`, `769f80b5bcb42ed0` |
| reqwest | 0.12.28 | MIT OR Apache-2.0 | https://github.com/seanmonstar/reqwest | `2db114247fb505b3`, `54987d63f2660141` |
| ring | 0.17.14 | Apache-2.0 AND ISC | https://github.com/briansmith/ring | `07414b6c33f30acf`, `edb9c6dbff4676b9`, `f3ba8fc296a970c9` |
| rustc_version | 0.4.1 | MIT OR Apache-2.0 | https://github.com/djc/rustc-version-rs | `769f80b5bcb42ed0`, `8d1f81ea4e87111d` |
| rustls | 0.23.42 | Apache-2.0 OR ISC OR MIT | https://github.com/rustls/rustls | `769f80b5bcb42ed0`, `a3320aa8d192a02c`, `af6da3f3f6b4929e` |
| rustls-pki-types | 1.15.0 | MIT OR Apache-2.0 | https://github.com/rustls/pki-types | `925e846006fdd216`, `c5e7f780f961f850` |
| rustls-webpki | 0.103.13 | ISC | https://github.com/rustls/webpki | `3ac27594ed56fd07` |
| ryu | 1.0.23 | Apache-2.0 OR BSL-1.0 | https://github.com/dtolnay/ryu | `8d8291caf1cee26d`, `95bd3988beee069f` |
| same-file | 1.0.6 | Unlicense OR MIT | https://github.com/BurntSushi/same-file | `65314a6c96683f76`, `739620ea44ad8f99`, `ca2abdf695884c77` |
| semver | 1.0.28 | MIT OR Apache-2.0 | https://github.com/dtolnay/semver | `30fefc3a7d6a0041`, `95bd3988beee069f` |
| serde | 1.0.229 | MIT OR Apache-2.0 | https://github.com/serde-rs/serde | `30fefc3a7d6a0041`, `95bd3988beee069f` |
| serde_core | 1.0.229 | MIT OR Apache-2.0 | https://github.com/serde-rs/serde | `30fefc3a7d6a0041`, `95bd3988beee069f` |
| serde_derive | 1.0.229 | MIT OR Apache-2.0 | https://github.com/serde-rs/serde | `30fefc3a7d6a0041`, `95bd3988beee069f` |
| serde_json | 1.0.151 | MIT OR Apache-2.0 | https://github.com/serde-rs/json | `30fefc3a7d6a0041`, `95bd3988beee069f` |
| serde_spanned | 1.1.1 | MIT OR Apache-2.0 | https://github.com/toml-rs/toml | `4498464c2864825d`, `c5accbbd8546e94c` |
| serde_urlencoded | 0.7.1 | MIT OR Apache-2.0 | https://github.com/nox/serde_urlencoded | `95bd3988beee069f`, `b5dae95324262088` |
| sha1 | 0.10.7 | MIT OR Apache-2.0 | https://github.com/RustCrypto/hashes | `4031faf6212ee744`, `59013a5c8d3a19c2` |
| sha2 | 0.10.9 | MIT OR Apache-2.0 | https://github.com/RustCrypto/hashes | `4031faf6212ee744`, `59013a5c8d3a19c2` |
| sharded-slab | 0.1.7 | MIT | https://github.com/hawkw/sharded-slab | `23c3dce12b908f6f` |
| shlex | 2.0.1 | MIT OR Apache-2.0 | https://github.com/comex/rust-shlex | `a759ce38c686a204`, `cc5ba5589dfb7bbc` |
| slab | 0.4.12 | MIT | https://github.com/tokio-rs/slab | `12c7116c4425c559` |
| smallvec | 1.15.2 | MIT OR Apache-2.0 | https://github.com/servo/rust-smallvec | `769f80b5bcb42ed0`, `7f194ae45c2525a5` |
| socket2 | 0.6.5 | MIT OR Apache-2.0 | https://github.com/rust-lang/socket2 | `769f80b5bcb42ed0`, `84e1bbfebd74e419` |
| stable_deref_trait | 1.2.1 | MIT OR Apache-2.0 | https://github.com/storyyeller/stable_deref_trait | `5e05b024f653a5ce`, `769f80b5bcb42ed0` |
| strsim | 0.11.1 | MIT | https://github.com/rapidfuzz/strsim-rs | `8fd8980cab8977a5` |
| subtle | 2.6.1 | BSD-3-Clause | https://github.com/dalek-cryptography/subtle | `24fa06d8eae3c3ba` |
| syn | 2.0.119 | MIT OR Apache-2.0 | https://github.com/dtolnay/syn | `30fefc3a7d6a0041`, `95bd3988beee069f` |
| syn | 3.0.2 | MIT OR Apache-2.0 | https://github.com/dtolnay/syn | `30fefc3a7d6a0041`, `95bd3988beee069f` |
| sync_wrapper | 1.0.2 | Apache-2.0 | https://github.com/Actyx/sync_wrapper | `0cec06e0e55fbc3d` |
| synstructure | 0.13.2 | MIT | https://github.com/mystor/synstructure | `3a036676ec8c0dba` |
| tempfile | 3.27.0 | MIT OR Apache-2.0 | https://github.com/Stebalien/tempfile | `769f80b5bcb42ed0`, `7bdd5c5e8ad0c973` |
| thiserror | 1.0.69 | MIT OR Apache-2.0 | https://github.com/dtolnay/thiserror | `30fefc3a7d6a0041`, `95bd3988beee069f` |
| thiserror | 2.0.19 | MIT OR Apache-2.0 | https://github.com/dtolnay/thiserror | `30fefc3a7d6a0041`, `95bd3988beee069f` |
| thiserror-impl | 1.0.69 | MIT OR Apache-2.0 | https://github.com/dtolnay/thiserror | `30fefc3a7d6a0041`, `95bd3988beee069f` |
| thiserror-impl | 2.0.19 | MIT OR Apache-2.0 | https://github.com/dtolnay/thiserror | `30fefc3a7d6a0041`, `95bd3988beee069f` |
| thread_local | 1.1.10 | MIT OR Apache-2.0 | https://github.com/Amanieu/thread_local-rs | `769f80b5bcb42ed0`, `8d1f81ea4e87111d` |
| tinystr | 0.8.3 | Unicode-3.0 | https://github.com/unicode-org/icu4x | `cde87abe221f413f` |
| tokio | 1.53.1 | MIT | https://github.com/tokio-rs/tokio | `3e1bef82aa0dfee4` |
| tokio-macros | 2.7.1 | MIT | https://github.com/tokio-rs/tokio | `c0fdcda1a4ffc5fd` |
| tokio-rustls | 0.26.4 | MIT OR Apache-2.0 | https://github.com/rustls/tokio-rustls | `1b0258c48739a24e`, `720304e6515d46fd` |
| tokio-tungstenite | 0.27.0 | MIT | https://github.com/snapview/tokio-tungstenite | `5c07409e74572128` |
| tokio-util | 0.7.18 | MIT | https://github.com/tokio-rs/tokio | `3e1bef82aa0dfee4` |
| toml | 1.1.3+spec-1.1.0 | MIT OR Apache-2.0 | https://github.com/toml-rs/toml | `4498464c2864825d`, `c5accbbd8546e94c` |
| toml_datetime | 1.1.1+spec-1.1.0 | MIT OR Apache-2.0 | https://github.com/toml-rs/toml | `4498464c2864825d`, `c5accbbd8546e94c` |
| toml_parser | 1.1.2+spec-1.1.0 | MIT OR Apache-2.0 | https://github.com/toml-rs/toml | `4498464c2864825d`, `c5accbbd8546e94c` |
| toml_writer | 1.1.2+spec-1.1.0 | MIT OR Apache-2.0 | https://github.com/toml-rs/toml | `4498464c2864825d`, `c5accbbd8546e94c` |
| tower | 0.5.3 | MIT | https://github.com/tower-rs/tower | `da6b30502badfa05` |
| tower-http | 0.6.11 | MIT | https://github.com/tower-rs/tower-http | `edd4b164997f6709` |
| tower-layer | 0.3.3 | MIT | https://github.com/tower-rs/tower | `da6b30502badfa05` |
| tower-service | 0.3.3 | MIT | https://github.com/tower-rs/tower | `da6b30502badfa05` |
| tracing | 0.1.44 | MIT | https://github.com/tokio-rs/tracing | `c1e08ee9a7288bf6` |
| tracing-attributes | 0.1.31 | MIT | https://github.com/tokio-rs/tracing | `c1e08ee9a7288bf6` |
| tracing-core | 0.1.36 | MIT | https://github.com/tokio-rs/tracing | `c1e08ee9a7288bf6` |
| tracing-log | 0.2.0 | MIT | https://github.com/tokio-rs/tracing | `c1e08ee9a7288bf6` |
| tracing-serde | 0.2.0 | MIT | https://github.com/tokio-rs/tracing | `c1e08ee9a7288bf6` |
| tracing-subscriber | 0.3.23 | MIT | https://github.com/tokio-rs/tracing | `c1e08ee9a7288bf6` |
| try-lock | 0.2.5 | MIT | https://github.com/seanmonstar/try-lock | `381f992f70f7089d` |
| tungstenite | 0.27.0 | MIT OR Apache-2.0 | https://github.com/snapview/tungstenite-rs | `769f80b5bcb42ed0`, `a69edb2155ca65cd` |
| typenum | 1.20.1 | MIT OR Apache-2.0 | https://github.com/paholg/typenum | `516b24e051bf5630`, `87ebb37988efc328`, `db11fec9946737df` |
| unicode-ident | 1.0.24 | (MIT OR Apache-2.0) AND Unicode-3.0 | https://github.com/dtolnay/unicode-ident | `30fefc3a7d6a0041`, `361d7912957842f2`, `95bd3988beee069f` |
| untrusted | 0.9.0 | ISC | https://github.com/briansmith/untrusted | `a1fff344297822d3` |
| url | 2.5.8 | MIT OR Apache-2.0 | https://github.com/servo/rust-url | `769f80b5bcb42ed0`, `7a8093fb4a93f23e` |
| utf-8 | 0.7.6 | MIT OR Apache-2.0 | https://github.com/SimonSapin/rust-utf8 | `30fefc3a7d6a0041`, `95bd3988beee069f` |
| utf8_iter | 1.0.4 | Apache-2.0 OR MIT | https://github.com/hsivonen/utf8_iter | `58d1e17ffe5109a7`, `76c0e37c107dd35a`, `7dc2f64024477c92` |
| utf8parse | 0.2.2 | Apache-2.0 OR MIT | https://github.com/alacritty/vte | `95bd3988beee069f`, `db2c904eb5685e69` |
| version_check | 0.9.5 | MIT OR Apache-2.0 | https://github.com/SergioBenitez/version_check | `769f80b5bcb42ed0`, `ed2fda479dacddad` |
| vswhom | 0.1.0 | MIT | https://github.com/nabijaczleweli/vswhom.rs | `b9720ca7a91fb6bf` |
| vswhom-sys | 0.1.3 | MIT | https://github.com/nabijaczleweli/vswhom-sys.rs | `b9720ca7a91fb6bf` |
| walkdir | 2.5.0 | Unlicense OR MIT | https://github.com/BurntSushi/walkdir | `154c1af2b38e25e5`, `65314a6c96683f76`, `ca2abdf695884c77` |
| want | 0.3.1 | MIT | https://github.com/seanmonstar/want | `f7dfffe03f9faba8` |
| webpki-roots | 1.0.9 | CDLA-Permissive-2.0 | https://github.com/rustls/webpki-roots | `d30183ec6610abca` |
| win32job | 2.0.3 | MIT OR Apache-2.0 | https://github.com/ohadravid/win32job-rs | `30fefc3a7d6a0041`, `769f80b5bcb42ed0` |
| winapi | 0.3.9 | MIT OR Apache-2.0 | https://github.com/retep998/winapi-rs | `2d01145596179ab6`, `c5accbbd8546e94c` |
| winapi-util | 0.1.11 | Unlicense OR MIT | https://github.com/BurntSushi/winapi-util | `65314a6c96683f76`, `739620ea44ad8f99`, `ca2abdf695884c77` |
| windows | 0.61.3 | MIT OR Apache-2.0 | https://github.com/microsoft/windows-rs | `72de958052e494b0`, `d9a1b1e30d633d57` |
| windows-collections | 0.2.0 | MIT OR Apache-2.0 | https://github.com/microsoft/windows-rs | `72de958052e494b0`, `d9a1b1e30d633d57` |
| windows-core | 0.61.2 | MIT OR Apache-2.0 | https://github.com/microsoft/windows-rs | `72de958052e494b0`, `d9a1b1e30d633d57` |
| windows-future | 0.2.1 | MIT OR Apache-2.0 | https://github.com/microsoft/windows-rs | `72de958052e494b0`, `d9a1b1e30d633d57` |
| windows-implement | 0.60.2 | MIT OR Apache-2.0 | https://github.com/microsoft/windows-rs | `72de958052e494b0`, `d9a1b1e30d633d57` |
| windows-interface | 0.59.3 | MIT OR Apache-2.0 | https://github.com/microsoft/windows-rs | `72de958052e494b0`, `d9a1b1e30d633d57` |
| windows-link | 0.1.3 | MIT OR Apache-2.0 | https://github.com/microsoft/windows-rs | `72de958052e494b0`, `d9a1b1e30d633d57` |
| windows-link | 0.2.1 | MIT OR Apache-2.0 | https://github.com/microsoft/windows-rs | `72de958052e494b0`, `d9a1b1e30d633d57` |
| windows-numerics | 0.2.0 | MIT OR Apache-2.0 | https://github.com/microsoft/windows-rs | `72de958052e494b0`, `d9a1b1e30d633d57` |
| windows-permissions | 0.2.4 | MIT | https://github.com/danieldulaney/windows-permissions-rs | `ae09dc340e428c37` |
| windows-result | 0.3.4 | MIT OR Apache-2.0 | https://github.com/microsoft/windows-rs | `72de958052e494b0`, `d9a1b1e30d633d57` |
| windows-strings | 0.4.2 | MIT OR Apache-2.0 | https://github.com/microsoft/windows-rs | `72de958052e494b0`, `d9a1b1e30d633d57` |
| windows-sys | 0.52.0 | MIT OR Apache-2.0 | https://github.com/microsoft/windows-rs | `72de958052e494b0`, `d9a1b1e30d633d57` |
| windows-sys | 0.59.0 | MIT OR Apache-2.0 | https://github.com/microsoft/windows-rs | `72de958052e494b0`, `d9a1b1e30d633d57` |
| windows-sys | 0.60.2 | MIT OR Apache-2.0 | https://github.com/microsoft/windows-rs | `72de958052e494b0`, `d9a1b1e30d633d57` |
| windows-sys | 0.61.2 | MIT OR Apache-2.0 | https://github.com/microsoft/windows-rs | `72de958052e494b0`, `d9a1b1e30d633d57` |
| windows-targets | 0.52.6 | MIT OR Apache-2.0 | https://github.com/microsoft/windows-rs | `72de958052e494b0`, `d9a1b1e30d633d57` |
| windows-targets | 0.53.5 | MIT OR Apache-2.0 | https://github.com/microsoft/windows-rs | `72de958052e494b0`, `d9a1b1e30d633d57` |
| windows-threading | 0.1.0 | MIT OR Apache-2.0 | https://github.com/microsoft/windows-rs | `72de958052e494b0`, `d9a1b1e30d633d57` |
| windows_x86_64_msvc | 0.52.6 | MIT OR Apache-2.0 | https://github.com/microsoft/windows-rs | `72de958052e494b0`, `d9a1b1e30d633d57` |
| windows_x86_64_msvc | 0.53.1 | MIT OR Apache-2.0 | https://github.com/microsoft/windows-rs | `72de958052e494b0`, `d9a1b1e30d633d57` |
| winnow | 1.0.4 | MIT | https://github.com/winnow-rs/winnow | `8793aa4141de4b16` |
| winreg | 0.55.0 | MIT | https://github.com/gentoo90/winreg-rs | `d9ba37d9bbdf711b` |
| winx | 0.36.4 | Apache-2.0 WITH LLVM-exception | https://github.com/sunfishcode/winx | `23823edf263108ef` |
| writeable | 0.6.3 | Unicode-3.0 | https://github.com/unicode-org/icu4x | `cde87abe221f413f` |
| yoke | 0.8.3 | Unicode-3.0 | https://github.com/unicode-org/icu4x | `cde87abe221f413f` |
| yoke-derive | 0.8.2 | Unicode-3.0 | https://github.com/unicode-org/icu4x | `cde87abe221f413f` |
| zerocopy | 0.8.55 | BSD-2-Clause OR Apache-2.0 OR MIT | https://github.com/google/zerocopy | `47248d1ec833e077`, `75a373c5dfcd3e03`, `a03d4daa4f46496a` |
| zerofrom | 0.1.8 | Unicode-3.0 | https://github.com/unicode-org/icu4x | `cde87abe221f413f` |
| zerofrom-derive | 0.1.7 | Unicode-3.0 | https://github.com/unicode-org/icu4x | `cde87abe221f413f` |
| zeroize | 1.9.0 | Apache-2.0 OR MIT | https://github.com/RustCrypto/utils | `58d1e17ffe5109a7`, `836ed921bbad486c` |
| zerotrie | 0.2.4 | Unicode-3.0 | https://github.com/unicode-org/icu4x | `cde87abe221f413f` |
| zerovec | 0.11.6 | Unicode-3.0 | https://github.com/unicode-org/icu4x | `cde87abe221f413f` |
| zerovec-derive | 0.11.3 | Unicode-3.0 | https://github.com/unicode-org/icu4x | `cde87abe221f413f` |
| zmij | 1.0.23 | MIT | https://github.com/dtolnay/zmij | `30fefc3a7d6a0041` |

## Frontend build dependencies

These packages are used to build and test the embedded browser bundle; they are
not installed beside the application at runtime. They remain listed for supply
chain transparency.

| Package | Version | Declared license | Source |
|---|---:|---|---|
| @asamuzakjp/css-color | 3.2.0 | MIT | https://registry.npmjs.org/@asamuzakjp/css-color/-/css-color-3.2.0.tgz |
| @csstools/color-helpers | 5.1.0 | MIT-0 | https://registry.npmjs.org/@csstools/color-helpers/-/color-helpers-5.1.0.tgz |
| @csstools/css-calc | 2.1.4 | MIT | https://registry.npmjs.org/@csstools/css-calc/-/css-calc-2.1.4.tgz |
| @csstools/css-color-parser | 3.1.0 | MIT | https://registry.npmjs.org/@csstools/css-color-parser/-/css-color-parser-3.1.0.tgz |
| @csstools/css-parser-algorithms | 3.0.5 | MIT | https://registry.npmjs.org/@csstools/css-parser-algorithms/-/css-parser-algorithms-3.0.5.tgz |
| @csstools/css-tokenizer | 3.0.4 | MIT | https://registry.npmjs.org/@csstools/css-tokenizer/-/css-tokenizer-3.0.4.tgz |
| @esbuild/aix-ppc64 | 0.25.12 | MIT | https://registry.npmjs.org/@esbuild/aix-ppc64/-/aix-ppc64-0.25.12.tgz |
| @esbuild/aix-ppc64 | 0.28.1 | MIT | https://registry.npmjs.org/@esbuild/aix-ppc64/-/aix-ppc64-0.28.1.tgz |
| @esbuild/android-arm | 0.25.12 | MIT | https://registry.npmjs.org/@esbuild/android-arm/-/android-arm-0.25.12.tgz |
| @esbuild/android-arm | 0.28.1 | MIT | https://registry.npmjs.org/@esbuild/android-arm/-/android-arm-0.28.1.tgz |
| @esbuild/android-arm64 | 0.25.12 | MIT | https://registry.npmjs.org/@esbuild/android-arm64/-/android-arm64-0.25.12.tgz |
| @esbuild/android-arm64 | 0.28.1 | MIT | https://registry.npmjs.org/@esbuild/android-arm64/-/android-arm64-0.28.1.tgz |
| @esbuild/android-x64 | 0.25.12 | MIT | https://registry.npmjs.org/@esbuild/android-x64/-/android-x64-0.25.12.tgz |
| @esbuild/android-x64 | 0.28.1 | MIT | https://registry.npmjs.org/@esbuild/android-x64/-/android-x64-0.28.1.tgz |
| @esbuild/darwin-arm64 | 0.25.12 | MIT | https://registry.npmjs.org/@esbuild/darwin-arm64/-/darwin-arm64-0.25.12.tgz |
| @esbuild/darwin-arm64 | 0.28.1 | MIT | https://registry.npmjs.org/@esbuild/darwin-arm64/-/darwin-arm64-0.28.1.tgz |
| @esbuild/darwin-x64 | 0.25.12 | MIT | https://registry.npmjs.org/@esbuild/darwin-x64/-/darwin-x64-0.25.12.tgz |
| @esbuild/darwin-x64 | 0.28.1 | MIT | https://registry.npmjs.org/@esbuild/darwin-x64/-/darwin-x64-0.28.1.tgz |
| @esbuild/freebsd-arm64 | 0.25.12 | MIT | https://registry.npmjs.org/@esbuild/freebsd-arm64/-/freebsd-arm64-0.25.12.tgz |
| @esbuild/freebsd-arm64 | 0.28.1 | MIT | https://registry.npmjs.org/@esbuild/freebsd-arm64/-/freebsd-arm64-0.28.1.tgz |
| @esbuild/freebsd-x64 | 0.25.12 | MIT | https://registry.npmjs.org/@esbuild/freebsd-x64/-/freebsd-x64-0.25.12.tgz |
| @esbuild/freebsd-x64 | 0.28.1 | MIT | https://registry.npmjs.org/@esbuild/freebsd-x64/-/freebsd-x64-0.28.1.tgz |
| @esbuild/linux-arm | 0.25.12 | MIT | https://registry.npmjs.org/@esbuild/linux-arm/-/linux-arm-0.25.12.tgz |
| @esbuild/linux-arm | 0.28.1 | MIT | https://registry.npmjs.org/@esbuild/linux-arm/-/linux-arm-0.28.1.tgz |
| @esbuild/linux-arm64 | 0.25.12 | MIT | https://registry.npmjs.org/@esbuild/linux-arm64/-/linux-arm64-0.25.12.tgz |
| @esbuild/linux-arm64 | 0.28.1 | MIT | https://registry.npmjs.org/@esbuild/linux-arm64/-/linux-arm64-0.28.1.tgz |
| @esbuild/linux-ia32 | 0.25.12 | MIT | https://registry.npmjs.org/@esbuild/linux-ia32/-/linux-ia32-0.25.12.tgz |
| @esbuild/linux-ia32 | 0.28.1 | MIT | https://registry.npmjs.org/@esbuild/linux-ia32/-/linux-ia32-0.28.1.tgz |
| @esbuild/linux-loong64 | 0.25.12 | MIT | https://registry.npmjs.org/@esbuild/linux-loong64/-/linux-loong64-0.25.12.tgz |
| @esbuild/linux-loong64 | 0.28.1 | MIT | https://registry.npmjs.org/@esbuild/linux-loong64/-/linux-loong64-0.28.1.tgz |
| @esbuild/linux-mips64el | 0.25.12 | MIT | https://registry.npmjs.org/@esbuild/linux-mips64el/-/linux-mips64el-0.25.12.tgz |
| @esbuild/linux-mips64el | 0.28.1 | MIT | https://registry.npmjs.org/@esbuild/linux-mips64el/-/linux-mips64el-0.28.1.tgz |
| @esbuild/linux-ppc64 | 0.25.12 | MIT | https://registry.npmjs.org/@esbuild/linux-ppc64/-/linux-ppc64-0.25.12.tgz |
| @esbuild/linux-ppc64 | 0.28.1 | MIT | https://registry.npmjs.org/@esbuild/linux-ppc64/-/linux-ppc64-0.28.1.tgz |
| @esbuild/linux-riscv64 | 0.25.12 | MIT | https://registry.npmjs.org/@esbuild/linux-riscv64/-/linux-riscv64-0.25.12.tgz |
| @esbuild/linux-riscv64 | 0.28.1 | MIT | https://registry.npmjs.org/@esbuild/linux-riscv64/-/linux-riscv64-0.28.1.tgz |
| @esbuild/linux-s390x | 0.25.12 | MIT | https://registry.npmjs.org/@esbuild/linux-s390x/-/linux-s390x-0.25.12.tgz |
| @esbuild/linux-s390x | 0.28.1 | MIT | https://registry.npmjs.org/@esbuild/linux-s390x/-/linux-s390x-0.28.1.tgz |
| @esbuild/linux-x64 | 0.25.12 | MIT | https://registry.npmjs.org/@esbuild/linux-x64/-/linux-x64-0.25.12.tgz |
| @esbuild/linux-x64 | 0.28.1 | MIT | https://registry.npmjs.org/@esbuild/linux-x64/-/linux-x64-0.28.1.tgz |
| @esbuild/netbsd-arm64 | 0.25.12 | MIT | https://registry.npmjs.org/@esbuild/netbsd-arm64/-/netbsd-arm64-0.25.12.tgz |
| @esbuild/netbsd-arm64 | 0.28.1 | MIT | https://registry.npmjs.org/@esbuild/netbsd-arm64/-/netbsd-arm64-0.28.1.tgz |
| @esbuild/netbsd-x64 | 0.25.12 | MIT | https://registry.npmjs.org/@esbuild/netbsd-x64/-/netbsd-x64-0.25.12.tgz |
| @esbuild/netbsd-x64 | 0.28.1 | MIT | https://registry.npmjs.org/@esbuild/netbsd-x64/-/netbsd-x64-0.28.1.tgz |
| @esbuild/openbsd-arm64 | 0.25.12 | MIT | https://registry.npmjs.org/@esbuild/openbsd-arm64/-/openbsd-arm64-0.25.12.tgz |
| @esbuild/openbsd-arm64 | 0.28.1 | MIT | https://registry.npmjs.org/@esbuild/openbsd-arm64/-/openbsd-arm64-0.28.1.tgz |
| @esbuild/openbsd-x64 | 0.25.12 | MIT | https://registry.npmjs.org/@esbuild/openbsd-x64/-/openbsd-x64-0.25.12.tgz |
| @esbuild/openbsd-x64 | 0.28.1 | MIT | https://registry.npmjs.org/@esbuild/openbsd-x64/-/openbsd-x64-0.28.1.tgz |
| @esbuild/openharmony-arm64 | 0.25.12 | MIT | https://registry.npmjs.org/@esbuild/openharmony-arm64/-/openharmony-arm64-0.25.12.tgz |
| @esbuild/openharmony-arm64 | 0.28.1 | MIT | https://registry.npmjs.org/@esbuild/openharmony-arm64/-/openharmony-arm64-0.28.1.tgz |
| @esbuild/sunos-x64 | 0.25.12 | MIT | https://registry.npmjs.org/@esbuild/sunos-x64/-/sunos-x64-0.25.12.tgz |
| @esbuild/sunos-x64 | 0.28.1 | MIT | https://registry.npmjs.org/@esbuild/sunos-x64/-/sunos-x64-0.28.1.tgz |
| @esbuild/win32-arm64 | 0.25.12 | MIT | https://registry.npmjs.org/@esbuild/win32-arm64/-/win32-arm64-0.25.12.tgz |
| @esbuild/win32-arm64 | 0.28.1 | MIT | https://registry.npmjs.org/@esbuild/win32-arm64/-/win32-arm64-0.28.1.tgz |
| @esbuild/win32-ia32 | 0.25.12 | MIT | https://registry.npmjs.org/@esbuild/win32-ia32/-/win32-ia32-0.25.12.tgz |
| @esbuild/win32-ia32 | 0.28.1 | MIT | https://registry.npmjs.org/@esbuild/win32-ia32/-/win32-ia32-0.28.1.tgz |
| @esbuild/win32-x64 | 0.25.12 | MIT | https://registry.npmjs.org/@esbuild/win32-x64/-/win32-x64-0.25.12.tgz |
| @esbuild/win32-x64 | 0.28.1 | MIT | https://registry.npmjs.org/@esbuild/win32-x64/-/win32-x64-0.28.1.tgz |
| @jridgewell/sourcemap-codec | 1.5.5 | MIT | https://registry.npmjs.org/@jridgewell/sourcemap-codec/-/sourcemap-codec-1.5.5.tgz |
| @rollup/rollup-android-arm-eabi | 4.62.2 | MIT | https://registry.npmjs.org/@rollup/rollup-android-arm-eabi/-/rollup-android-arm-eabi-4.62.2.tgz |
| @rollup/rollup-android-arm64 | 4.62.2 | MIT | https://registry.npmjs.org/@rollup/rollup-android-arm64/-/rollup-android-arm64-4.62.2.tgz |
| @rollup/rollup-darwin-arm64 | 4.62.2 | MIT | https://registry.npmjs.org/@rollup/rollup-darwin-arm64/-/rollup-darwin-arm64-4.62.2.tgz |
| @rollup/rollup-darwin-x64 | 4.62.2 | MIT | https://registry.npmjs.org/@rollup/rollup-darwin-x64/-/rollup-darwin-x64-4.62.2.tgz |
| @rollup/rollup-freebsd-arm64 | 4.62.2 | MIT | https://registry.npmjs.org/@rollup/rollup-freebsd-arm64/-/rollup-freebsd-arm64-4.62.2.tgz |
| @rollup/rollup-freebsd-x64 | 4.62.2 | MIT | https://registry.npmjs.org/@rollup/rollup-freebsd-x64/-/rollup-freebsd-x64-4.62.2.tgz |
| @rollup/rollup-linux-arm-gnueabihf | 4.62.2 | MIT | https://registry.npmjs.org/@rollup/rollup-linux-arm-gnueabihf/-/rollup-linux-arm-gnueabihf-4.62.2.tgz |
| @rollup/rollup-linux-arm-musleabihf | 4.62.2 | MIT | https://registry.npmjs.org/@rollup/rollup-linux-arm-musleabihf/-/rollup-linux-arm-musleabihf-4.62.2.tgz |
| @rollup/rollup-linux-arm64-gnu | 4.62.2 | MIT | https://registry.npmjs.org/@rollup/rollup-linux-arm64-gnu/-/rollup-linux-arm64-gnu-4.62.2.tgz |
| @rollup/rollup-linux-arm64-musl | 4.62.2 | MIT | https://registry.npmjs.org/@rollup/rollup-linux-arm64-musl/-/rollup-linux-arm64-musl-4.62.2.tgz |
| @rollup/rollup-linux-loong64-gnu | 4.62.2 | MIT | https://registry.npmjs.org/@rollup/rollup-linux-loong64-gnu/-/rollup-linux-loong64-gnu-4.62.2.tgz |
| @rollup/rollup-linux-loong64-musl | 4.62.2 | MIT | https://registry.npmjs.org/@rollup/rollup-linux-loong64-musl/-/rollup-linux-loong64-musl-4.62.2.tgz |
| @rollup/rollup-linux-ppc64-gnu | 4.62.2 | MIT | https://registry.npmjs.org/@rollup/rollup-linux-ppc64-gnu/-/rollup-linux-ppc64-gnu-4.62.2.tgz |
| @rollup/rollup-linux-ppc64-musl | 4.62.2 | MIT | https://registry.npmjs.org/@rollup/rollup-linux-ppc64-musl/-/rollup-linux-ppc64-musl-4.62.2.tgz |
| @rollup/rollup-linux-riscv64-gnu | 4.62.2 | MIT | https://registry.npmjs.org/@rollup/rollup-linux-riscv64-gnu/-/rollup-linux-riscv64-gnu-4.62.2.tgz |
| @rollup/rollup-linux-riscv64-musl | 4.62.2 | MIT | https://registry.npmjs.org/@rollup/rollup-linux-riscv64-musl/-/rollup-linux-riscv64-musl-4.62.2.tgz |
| @rollup/rollup-linux-s390x-gnu | 4.62.2 | MIT | https://registry.npmjs.org/@rollup/rollup-linux-s390x-gnu/-/rollup-linux-s390x-gnu-4.62.2.tgz |
| @rollup/rollup-linux-x64-gnu | 4.62.2 | MIT | https://registry.npmjs.org/@rollup/rollup-linux-x64-gnu/-/rollup-linux-x64-gnu-4.62.2.tgz |
| @rollup/rollup-linux-x64-musl | 4.62.2 | MIT | https://registry.npmjs.org/@rollup/rollup-linux-x64-musl/-/rollup-linux-x64-musl-4.62.2.tgz |
| @rollup/rollup-openbsd-x64 | 4.62.2 | MIT | https://registry.npmjs.org/@rollup/rollup-openbsd-x64/-/rollup-openbsd-x64-4.62.2.tgz |
| @rollup/rollup-openharmony-arm64 | 4.62.2 | MIT | https://registry.npmjs.org/@rollup/rollup-openharmony-arm64/-/rollup-openharmony-arm64-4.62.2.tgz |
| @rollup/rollup-win32-arm64-msvc | 4.62.2 | MIT | https://registry.npmjs.org/@rollup/rollup-win32-arm64-msvc/-/rollup-win32-arm64-msvc-4.62.2.tgz |
| @rollup/rollup-win32-ia32-msvc | 4.62.2 | MIT | https://registry.npmjs.org/@rollup/rollup-win32-ia32-msvc/-/rollup-win32-ia32-msvc-4.62.2.tgz |
| @rollup/rollup-win32-x64-gnu | 4.62.2 | MIT | https://registry.npmjs.org/@rollup/rollup-win32-x64-gnu/-/rollup-win32-x64-gnu-4.62.2.tgz |
| @rollup/rollup-win32-x64-msvc | 4.62.2 | MIT | https://registry.npmjs.org/@rollup/rollup-win32-x64-msvc/-/rollup-win32-x64-msvc-4.62.2.tgz |
| @types/chai | 5.2.3 | MIT | https://registry.npmjs.org/@types/chai/-/chai-5.2.3.tgz |
| @types/deep-eql | 4.0.2 | MIT | https://registry.npmjs.org/@types/deep-eql/-/deep-eql-4.0.2.tgz |
| @types/estree | 1.0.9 | MIT | https://registry.npmjs.org/@types/estree/-/estree-1.0.9.tgz |
| @types/node | 24.13.3 | MIT | https://registry.npmjs.org/@types/node/-/node-24.13.3.tgz |
| @vitest/expect | 3.2.7 | MIT | https://registry.npmjs.org/@vitest/expect/-/expect-3.2.7.tgz |
| @vitest/mocker | 3.2.7 | MIT | https://registry.npmjs.org/@vitest/mocker/-/mocker-3.2.7.tgz |
| @vitest/pretty-format | 3.2.7 | MIT | https://registry.npmjs.org/@vitest/pretty-format/-/pretty-format-3.2.7.tgz |
| @vitest/runner | 3.2.7 | MIT | https://registry.npmjs.org/@vitest/runner/-/runner-3.2.7.tgz |
| @vitest/snapshot | 3.2.7 | MIT | https://registry.npmjs.org/@vitest/snapshot/-/snapshot-3.2.7.tgz |
| @vitest/spy | 3.2.7 | MIT | https://registry.npmjs.org/@vitest/spy/-/spy-3.2.7.tgz |
| @vitest/utils | 3.2.7 | MIT | https://registry.npmjs.org/@vitest/utils/-/utils-3.2.7.tgz |
| agent-base | 7.1.4 | MIT | https://registry.npmjs.org/agent-base/-/agent-base-7.1.4.tgz |
| assertion-error | 2.0.1 | MIT | https://registry.npmjs.org/assertion-error/-/assertion-error-2.0.1.tgz |
| cac | 6.7.14 | MIT | https://registry.npmjs.org/cac/-/cac-6.7.14.tgz |
| chai | 5.3.3 | MIT | https://registry.npmjs.org/chai/-/chai-5.3.3.tgz |
| check-error | 2.1.3 | MIT | https://registry.npmjs.org/check-error/-/check-error-2.1.3.tgz |
| cssstyle | 4.6.0 | MIT | https://registry.npmjs.org/cssstyle/-/cssstyle-4.6.0.tgz |
| data-urls | 5.0.0 | MIT | https://registry.npmjs.org/data-urls/-/data-urls-5.0.0.tgz |
| debug | 4.4.3 | MIT | https://registry.npmjs.org/debug/-/debug-4.4.3.tgz |
| decimal.js | 10.6.0 | MIT | https://registry.npmjs.org/decimal.js/-/decimal.js-10.6.0.tgz |
| deep-eql | 5.0.2 | MIT | https://registry.npmjs.org/deep-eql/-/deep-eql-5.0.2.tgz |
| entities | 6.0.1 | BSD-2-Clause | https://registry.npmjs.org/entities/-/entities-6.0.1.tgz |
| es-module-lexer | 1.7.0 | MIT | https://registry.npmjs.org/es-module-lexer/-/es-module-lexer-1.7.0.tgz |
| esbuild | 0.25.12 | MIT | https://registry.npmjs.org/esbuild/-/esbuild-0.25.12.tgz |
| esbuild | 0.28.1 | MIT | https://registry.npmjs.org/esbuild/-/esbuild-0.28.1.tgz |
| estree-walker | 3.0.3 | MIT | https://registry.npmjs.org/estree-walker/-/estree-walker-3.0.3.tgz |
| expect-type | 1.4.0 | Apache-2.0 | https://registry.npmjs.org/expect-type/-/expect-type-1.4.0.tgz |
| fdir | 6.5.0 | MIT | https://registry.npmjs.org/fdir/-/fdir-6.5.0.tgz |
| fsevents | 2.3.3 | MIT | https://registry.npmjs.org/fsevents/-/fsevents-2.3.3.tgz |
| html-encoding-sniffer | 4.0.0 | MIT | https://registry.npmjs.org/html-encoding-sniffer/-/html-encoding-sniffer-4.0.0.tgz |
| http-proxy-agent | 7.0.2 | MIT | https://registry.npmjs.org/http-proxy-agent/-/http-proxy-agent-7.0.2.tgz |
| https-proxy-agent | 7.0.6 | MIT | https://registry.npmjs.org/https-proxy-agent/-/https-proxy-agent-7.0.6.tgz |
| iconv-lite | 0.6.3 | MIT | https://registry.npmjs.org/iconv-lite/-/iconv-lite-0.6.3.tgz |
| is-potential-custom-element-name | 1.0.1 | MIT | https://registry.npmjs.org/is-potential-custom-element-name/-/is-potential-custom-element-name-1.0.1.tgz |
| js-tokens | 9.0.1 | MIT | https://registry.npmjs.org/js-tokens/-/js-tokens-9.0.1.tgz |
| jsdom | 26.1.0 | MIT | https://registry.npmjs.org/jsdom/-/jsdom-26.1.0.tgz |
| loupe | 3.2.1 | MIT | https://registry.npmjs.org/loupe/-/loupe-3.2.1.tgz |
| lru-cache | 10.4.3 | ISC | https://registry.npmjs.org/lru-cache/-/lru-cache-10.4.3.tgz |
| magic-string | 0.30.21 | MIT | https://registry.npmjs.org/magic-string/-/magic-string-0.30.21.tgz |
| ms | 2.1.3 | MIT | https://registry.npmjs.org/ms/-/ms-2.1.3.tgz |
| nanoid | 3.3.16 | MIT | https://registry.npmjs.org/nanoid/-/nanoid-3.3.16.tgz |
| nwsapi | 2.2.24 | MIT | https://registry.npmjs.org/nwsapi/-/nwsapi-2.2.24.tgz |
| parse5 | 7.3.0 | MIT | https://registry.npmjs.org/parse5/-/parse5-7.3.0.tgz |
| pathe | 2.0.3 | MIT | https://registry.npmjs.org/pathe/-/pathe-2.0.3.tgz |
| pathval | 2.0.1 | MIT | https://registry.npmjs.org/pathval/-/pathval-2.0.1.tgz |
| picocolors | 1.1.1 | ISC | https://registry.npmjs.org/picocolors/-/picocolors-1.1.1.tgz |
| picomatch | 4.0.5 | MIT | https://registry.npmjs.org/picomatch/-/picomatch-4.0.5.tgz |
| postcss | 8.5.21 | MIT | https://registry.npmjs.org/postcss/-/postcss-8.5.21.tgz |
| punycode | 2.3.1 | MIT | https://registry.npmjs.org/punycode/-/punycode-2.3.1.tgz |
| rollup | 4.62.2 | MIT | https://registry.npmjs.org/rollup/-/rollup-4.62.2.tgz |
| rrweb-cssom | 0.8.0 | MIT | https://registry.npmjs.org/rrweb-cssom/-/rrweb-cssom-0.8.0.tgz |
| safer-buffer | 2.1.2 | MIT | https://registry.npmjs.org/safer-buffer/-/safer-buffer-2.1.2.tgz |
| saxes | 6.0.0 | ISC | https://registry.npmjs.org/saxes/-/saxes-6.0.0.tgz |
| siginfo | 2.0.0 | ISC | https://registry.npmjs.org/siginfo/-/siginfo-2.0.0.tgz |
| source-map-js | 1.2.1 | BSD-3-Clause | https://registry.npmjs.org/source-map-js/-/source-map-js-1.2.1.tgz |
| stackback | 0.0.2 | MIT | https://registry.npmjs.org/stackback/-/stackback-0.0.2.tgz |
| std-env | 3.10.0 | MIT | https://registry.npmjs.org/std-env/-/std-env-3.10.0.tgz |
| strip-literal | 3.1.0 | MIT | https://registry.npmjs.org/strip-literal/-/strip-literal-3.1.0.tgz |
| symbol-tree | 3.2.4 | MIT | https://registry.npmjs.org/symbol-tree/-/symbol-tree-3.2.4.tgz |
| tinybench | 2.9.0 | MIT | https://registry.npmjs.org/tinybench/-/tinybench-2.9.0.tgz |
| tinyexec | 0.3.2 | MIT | https://registry.npmjs.org/tinyexec/-/tinyexec-0.3.2.tgz |
| tinyglobby | 0.2.17 | MIT | https://registry.npmjs.org/tinyglobby/-/tinyglobby-0.2.17.tgz |
| tinypool | 1.1.1 | MIT | https://registry.npmjs.org/tinypool/-/tinypool-1.1.1.tgz |
| tinyrainbow | 2.0.0 | MIT | https://registry.npmjs.org/tinyrainbow/-/tinyrainbow-2.0.0.tgz |
| tinyspy | 4.0.4 | MIT | https://registry.npmjs.org/tinyspy/-/tinyspy-4.0.4.tgz |
| tldts | 6.1.86 | MIT | https://registry.npmjs.org/tldts/-/tldts-6.1.86.tgz |
| tldts-core | 6.1.86 | MIT | https://registry.npmjs.org/tldts-core/-/tldts-core-6.1.86.tgz |
| tough-cookie | 5.1.2 | BSD-3-Clause | https://registry.npmjs.org/tough-cookie/-/tough-cookie-5.1.2.tgz |
| tr46 | 5.1.1 | MIT | https://registry.npmjs.org/tr46/-/tr46-5.1.1.tgz |
| typescript | 5.9.3 | Apache-2.0 | https://registry.npmjs.org/typescript/-/typescript-5.9.3.tgz |
| undici-types | 7.18.2 | MIT | https://registry.npmjs.org/undici-types/-/undici-types-7.18.2.tgz |
| vite | 7.3.6 | MIT | https://registry.npmjs.org/vite/-/vite-7.3.6.tgz |
| vite-node | 3.2.4 | MIT | https://registry.npmjs.org/vite-node/-/vite-node-3.2.4.tgz |
| vitest | 3.2.7 | MIT | https://registry.npmjs.org/vitest/-/vitest-3.2.7.tgz |
| w3c-xmlserializer | 5.0.0 | MIT | https://registry.npmjs.org/w3c-xmlserializer/-/w3c-xmlserializer-5.0.0.tgz |
| webidl-conversions | 7.0.0 | BSD-2-Clause | https://registry.npmjs.org/webidl-conversions/-/webidl-conversions-7.0.0.tgz |
| whatwg-encoding | 3.1.1 | MIT | https://registry.npmjs.org/whatwg-encoding/-/whatwg-encoding-3.1.1.tgz |
| whatwg-mimetype | 4.0.0 | MIT | https://registry.npmjs.org/whatwg-mimetype/-/whatwg-mimetype-4.0.0.tgz |
| whatwg-url | 14.2.0 | MIT | https://registry.npmjs.org/whatwg-url/-/whatwg-url-14.2.0.tgz |
| why-is-node-running | 2.3.0 | MIT | https://registry.npmjs.org/why-is-node-running/-/why-is-node-running-2.3.0.tgz |
| ws | 8.21.1 | MIT | https://registry.npmjs.org/ws/-/ws-8.21.1.tgz |
| xml-name-validator | 5.0.0 | Apache-2.0 | https://registry.npmjs.org/xml-name-validator/-/xml-name-validator-5.0.0.tgz |
| xmlchars | 2.2.0 | MIT | https://registry.npmjs.org/xmlchars/-/xmlchars-2.2.0.tgz |

## Trademarks

The application does not bundle Codex Desktop. OpenAI, ChatGPT, and Codex may be
trademarks of OpenAI. Their names are used only to describe compatibility.
